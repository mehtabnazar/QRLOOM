import React from "react";

interface LogoProps {
  theme?: "dark" | "light";
  compact?: boolean;
  onClick?: () => void;
  className?: string;
}

export default function Logo({ theme = "dark", compact = false, onClick, className = "" }: LogoProps) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 text-left transition-all hover:opacity-90 active:scale-[0.98] cursor-pointer group ${className}`}
      id="qrloom-brand-logo"
    >
      {/* Premium SVG Icon / Brand Mark */}
      <div className="relative flex-shrink-0 w-11 h-11 flex items-center justify-center rounded-xl bg-slate-950 border border-slate-800 shadow-lg shadow-emerald-500/10 group-hover:shadow-emerald-500/25 group-hover:scale-105 transition-all overflow-hidden">
        {/* Ambient Gradient Background in the Logo capsule */}
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 via-transparent to-emerald-400/5 opacity-80" />
        
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 100 100"
          className="w-8 h-8 relative z-10"
        >
          <defs>
            <linearGradient id="loomGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" /> {/* Emerald */}
              <stop offset="50%" stopColor="#34d399" /> {/* Mint */}
              <stop offset="100%" stopColor="#059669" /> {/* Deep Emerald */}
            </linearGradient>
            <filter id="subtleGlow" x="-10%" y="-10%" width="120%" height="120%">
              <feGaussianBlur stdDeviation="1.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Top-Left Finder */}
          <rect x="9" y="9" width="24" height="24" rx="7" fill="none" stroke="url(#loomGrad)" strokeWidth="8" />
          <rect x="17" y="17" width="8" height="8" rx="2.5" fill="url(#loomGrad)" />

          {/* Top-Right Finder */}
          <rect x="67" y="9" width="24" height="24" rx="7" fill="none" stroke="url(#loomGrad)" strokeWidth="8" />
          <rect x="75" y="17" width="8" height="8" rx="2.5" fill="url(#loomGrad)" />

          {/* Bottom-Left Finder */}
          <rect x="9" y="67" width="24" height="24" rx="7" fill="none" stroke="url(#loomGrad)" strokeWidth="8" />
          <rect x="17" y="75" width="8" height="8" rx="2.5" fill="url(#loomGrad)" />

          {/* Bottom-Right Arc */}
          <path d="M 67,91 A 24,24 0 0,1 91,67" fill="none" stroke="url(#loomGrad)" strokeWidth="8" strokeLinecap="round" />
          <circle cx="89" cy="89" r="4.5" fill="url(#loomGrad)" />

          {/* Top Center Dot */}
          <circle cx="50" cy="9.5" r="4.5" fill="url(#loomGrad)" />

          {/* Center-Left Dot */}
          <circle cx="9.5" cy="50" r="4.5" fill="url(#loomGrad)" />

          {/* Center J-Curve */}
          <path d="M 25,50 L 42,50 A 8,8 0 0,0 50,42 L 50,25" fill="none" stroke="url(#loomGrad)" strokeWidth="8" strokeLinecap="round" filter="url(#subtleGlow)" />

          {/* Center-Right Pill */}
          <rect x="62" y="45.5" width="16" height="9" rx="4.5" fill="url(#loomGrad)" />

          {/* Center-Far-Right Dot */}
          <circle cx="90.5" cy="50" r="4.5" fill="url(#loomGrad)" />

          {/* Bottom-Center Dot */}
          <circle cx="50" cy="67.5" r="4.5" fill="url(#loomGrad)" />

          {/* Bottom-Center Pill */}
          <rect x="45.5" y="80" width="9" height="15" rx="4.5" fill="url(#loomGrad)" />
        </svg>

        {/* Glowing Active Status Pulse Indicator */}
        <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
        <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-emerald-500 rounded-full" />
      </div>

      {/* Brand Text */}
      {!compact && (
        <div className="flex flex-col">
          <span
            className={`font-display font-extrabold text-lg sm:text-xl tracking-wider leading-none transition-colors ${
              theme === "dark"
                ? "bg-gradient-to-r from-white via-emerald-100 to-emerald-400 bg-clip-text text-transparent"
                : "bg-gradient-to-r from-slate-900 via-emerald-950 to-emerald-800 bg-clip-text text-transparent"
            }`}
          >
            QR LOOM
          </span>
          <span className="text-[9px] font-mono tracking-widest text-emerald-500 font-bold uppercase mt-0.5 leading-none">
            Studio
          </span>
        </div>
      )}
    </button>
  );
}
