import { QrCode, Github, Linkedin, Instagram, ArrowUp, Globe, Heart } from "lucide-react";
import Logo from "./Logo";

interface FooterProps {
  setCurrentPage: (page: string) => void;
  theme: "dark" | "light";
}

export default function Footer({ setCurrentPage, theme }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer
      id="main-footer"
      className={`relative border-t pt-16 pb-8 px-4 sm:px-6 lg:px-8 overflow-hidden backdrop-blur-sm transition-all duration-300 ${
        theme === "dark"
          ? "border-slate-800/80 bg-slate-950/80 text-slate-300"
          : "border-slate-200/90 bg-slate-100/90 text-slate-700"
      }`}
    >
      {/* Background Blobs for Visual Aesthetics */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 -translate-x-1/2 w-80 h-80 rounded-full bg-emerald-500/5 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-teal-500/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto z-10 relative">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-8 mb-12">
          {/* Column 1: Brand & Logo */}
          <div className="md:col-span-1 flex flex-col gap-4">
            <Logo
              theme={theme}
              onClick={() => {
                setCurrentPage("home");
                scrollToTop();
              }}
            />
            <p className={`text-sm leading-relaxed max-w-sm ${
              theme === "dark" ? "text-slate-400" : "text-slate-600"
            }`}>
              The professional cloud-native QR Loom platform. Generate fully customized 15+ QR code categories and access complete AI-powered document utilities 100% free of charge.
            </p>
            <div className="flex items-center gap-3.5 mt-2">
              <a
                href="https://github.com/QR-LOOM"
                target="_blank"
                rel="noopener noreferrer"
                className={`w-9 h-9 flex items-center justify-center rounded-lg border hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/10 transition-all duration-200 ${
                  theme === "dark"
                    ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-emerald-500"
                    : "bg-white border-slate-200 text-slate-600 hover:text-slate-950 hover:border-emerald-500"
                }`}
                title="GitHub"
              >
                <Github className="w-4.5 h-4.5" />
              </a>
              <a
                href="https://www.linkedin.com/company/qr-loom"
                target="_blank"
                rel="noopener noreferrer"
                className={`w-9 h-9 flex items-center justify-center rounded-lg border hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/10 transition-all duration-200 ${
                  theme === "dark"
                    ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-emerald-500"
                    : "bg-white border-slate-200 text-slate-600 hover:text-slate-950 hover:border-emerald-500"
                }`}
                title="LinkedIn"
              >
                <Linkedin className="w-4.5 h-4.5" />
              </a>
              <a
                href="https://www.instagram.com/qrloom_official"
                target="_blank"
                rel="noopener noreferrer"
                className={`w-9 h-9 flex items-center justify-center rounded-lg border hover:scale-105 hover:shadow-lg hover:shadow-emerald-500/10 transition-all duration-200 ${
                  theme === "dark"
                    ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-emerald-500"
                    : "bg-white border-slate-200 text-slate-600 hover:text-slate-950 hover:border-emerald-500"
                }`}
                title="Instagram"
              >
                <Instagram className="w-4.5 h-4.5" />
              </a>
            </div>
          </div>

          {/* Column 2: Platform Links */}
          <div className="flex flex-col gap-4">
            <h3 className={`font-display text-xs font-bold tracking-wider uppercase ${
              theme === "dark" ? "text-white" : "text-slate-900"
            }`}>
              Platform
            </h3>
            <ul className="flex flex-col gap-2.5">
              <li>
                <button
                  onClick={() => { setCurrentPage("home"); scrollToTop(); }}
                  className={`text-sm transition-colors text-left cursor-pointer font-medium ${
                    theme === "dark" ? "text-slate-400 hover:text-emerald-400" : "text-slate-600 hover:text-emerald-600"
                  }`}
                >
                  QR Code Generator
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setCurrentPage("pdf"); scrollToTop(); }}
                  className={`text-sm transition-colors text-left cursor-pointer font-medium ${
                    theme === "dark" ? "text-slate-400 hover:text-emerald-400" : "text-slate-600 hover:text-emerald-600"
                  }`}
                >
                  PDF & AI Document Suite
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setCurrentPage("features"); scrollToTop(); }}
                  className={`text-sm transition-colors text-left cursor-pointer font-medium ${
                    theme === "dark" ? "text-slate-400 hover:text-emerald-400" : "text-slate-600 hover:text-emerald-600"
                  }`}
                >
                  Features & Knowledge Hub
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Resources */}
          <div className="flex flex-col gap-4">
            <h3 className={`font-display text-xs font-bold tracking-wider uppercase ${
              theme === "dark" ? "text-white" : "text-slate-900"
            }`}>
              Support
            </h3>
            <ul className="flex flex-col gap-2.5">
              <li>
                <button
                  onClick={() => { setCurrentPage("faq"); scrollToTop(); }}
                  className={`text-sm transition-colors text-left cursor-pointer font-medium ${
                    theme === "dark" ? "text-slate-400 hover:text-emerald-400" : "text-slate-600 hover:text-emerald-600"
                  }`}
                >
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setCurrentPage("contact"); scrollToTop(); }}
                  className={`text-sm transition-colors text-left cursor-pointer font-medium ${
                    theme === "dark" ? "text-slate-400 hover:text-emerald-400" : "text-slate-600 hover:text-emerald-600"
                  }`}
                >
                  Contact Helpdesk
                </button>
              </li>
              <li>
                <span className={`text-sm flex items-center gap-1.5 select-none font-medium ${
                  theme === "dark" ? "text-slate-400" : "text-slate-600"
                }`}>
                  Status: <span className="text-emerald-500 font-bold flex items-center gap-1">● Online</span>
                </span>
              </li>
            </ul>
          </div>

          {/* Column 4: Trust Banner */}
          <div className={`flex flex-col gap-4 p-5 rounded-2xl border ${
            theme === "dark"
              ? "bg-slate-900/40 border-slate-800/80 shadow-inner shadow-slate-950/30"
              : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h4 className={`text-xs font-bold tracking-widest uppercase font-display ${
              theme === "dark" ? "text-white" : "text-slate-900"
            }`}>
              Client-Side Privacy
            </h4>
            <p className={`text-xs leading-relaxed ${
              theme === "dark" ? "text-slate-400" : "text-slate-600"
            }`}>
              We process QR generation and document modifications directly in your browser. Your text, parameters, and files are never sent to any external server.
            </p>
            <div className="text-[10px] font-mono font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-1 pt-1 border-t border-slate-800/20">
              🛡️ 100% Free • Unlimited • Secure
            </div>
          </div>
        </div>

        {/* Footer Bottom credits */}
        <div className={`border-t pt-8 mt-4 flex flex-col sm:flex-row items-center justify-between gap-4 ${
          theme === "dark" ? "border-slate-800/50" : "border-slate-200"
        }`}>
          <div className={`flex flex-col sm:flex-row items-center gap-2 sm:gap-6 text-xs ${
            theme === "dark" ? "text-slate-400" : "text-slate-600"
          }`}>
            <span>&copy; {currentYear} QR LOOM. All rights reserved.</span>
            <div className="flex gap-4 items-center">
              <button
                onClick={() => setCurrentPage("privacy")}
                className="hover:text-emerald-500 transition-colors cursor-pointer bg-transparent border-none p-0 text-xs font-semibold"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => setCurrentPage("terms")}
                className="hover:text-emerald-500 transition-colors cursor-pointer bg-transparent border-none p-0 text-xs font-semibold"
              >
                Terms of Service
              </button>
              <button
                onClick={() => setCurrentPage("knowledge")}
                className="hover:text-emerald-500 transition-colors cursor-pointer bg-transparent border-none p-0 text-xs font-semibold"
              >
                Knowledge Base
              </button>
            </div>
          </div>

          {/* MEHTAB NAZAR Link with custom style */}
          <div className="flex items-center gap-3">
            <div className={`text-xs flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border shadow-sm ${
              theme === "dark"
                ? "bg-slate-900/60 border-slate-800/80 text-slate-400"
                : "bg-white border-slate-200 text-slate-600"
            }`}>
              <span>Created with</span>
              <Heart className="w-3.5 h-3.5 text-emerald-500 fill-emerald-500 animate-pulse" />
              <span>by</span>
              <a
                href="https://mehtabnazar.xyz/"
                target="_blank"
                rel="noopener noreferrer"
                className="font-display font-semibold text-emerald-500 hover:text-emerald-400 transition-all duration-150 relative group flex items-center gap-0.5"
              >
                MEHTAB NAZAR
                <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-emerald-500 scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
                <Globe className="w-3 h-3 text-emerald-500 group-hover:rotate-12 transition-transform" />
              </a>
            </div>

            <button
              onClick={scrollToTop}
              className={`p-2.5 rounded-full border transition-all duration-200 ${
                theme === "dark"
                  ? "bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:border-emerald-500 hover:bg-slate-800/50"
                  : "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-emerald-500 hover:bg-slate-50"
              }`}
              title="Scroll to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
