import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, User } from "firebase/auth";
import { initializeFirestore, getFirestore, collection, addDoc, getDocs, query, orderBy, limit, doc, deleteDoc, where } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCe359KpjBGqz6kNSqkeWzEn4PWya2QbdQ",
  authDomain: "gen-lang-client-0507200038.firebaseapp.com",
  projectId: "gen-lang-client-0507200038",
  storageBucket: "gen-lang-client-0507200038.firebasestorage.app",
  messagingSenderId: "24203367485",
  appId: "1:24203367485:web:63f8b8994ed263b35b4654"
};

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with the specific databaseId from the configuration
const db = getFirestore(app, "ai-studio-qrloom-1892c4f0-52e6-47d8-abc0-4d477ede1bb5");

const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export { app, auth, db, googleProvider, signInWithPopup, signOut, collection, addDoc, getDocs, query, orderBy, limit, doc, deleteDoc, where };
export type { User };
