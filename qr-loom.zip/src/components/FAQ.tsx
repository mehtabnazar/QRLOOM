import { useState } from "react";
import { ChevronDown, ChevronUp, Shield } from "lucide-react";
import { motion } from "motion/react";

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQProps {
  theme?: "dark" | "light";
}

export default function FAQ({ theme = "dark" }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FAQItem[] = [
    {
      question: "Is this QR code generator completely free of charge?",
      answer: "Yes, 100%! QRLoom is a completely free open-benefit SaaS application. You can generate unlimited, high-resolution QR codes and utilize our full range of AI-powered document tools absolutely free, with zero ads, no sign-ups, and no hidden subscriptions.",
    },
    {
      question: "Do the generated QR codes have an expiration date?",
      answer: "No, they never expire! Because we generate static QR codes, your encoded URL, vCard, or text credentials are baked directly into the QR matrix pattern. It is an industry standard that remains active and scannable offline forever.",
    },
    {
      question: "Can I add custom brand logos over my QR code?",
      answer: "Absolutely! You can upload custom brand logos (PNG, JPEG) or choose from standard presets (WhatsApp, WiFi, Globe). Our engine renders the logo dead-center of the canvas and applies a white background mask, ensuring camera lenses can scan it comfortably.",
    },
    {
      question: "How do I scan a QR code?",
      answer: "Most modern smartphones have built-in QR readers. Simply open your iPhone or Android camera app, point it steadily at the QR code, and tap the notification link that pops up instantly on your screen.",
    },
    {
      question: "Is my personal data safe with QRLoom?",
      answer: "Completely safe. Unlike commercial marketing hubs, QRLoom processes QR generation and visual modifications entirely inside your browser cache. Your URLs, WiFi passwords, and vCard credentials never hit external databases. Our server only acts as a secure, stateless proxy for Gemini AI requests.",
    },
    {
      question: "Can I use the generated QR codes for commercial business?",
      answer: "Yes! There are absolutely no licensing restrictions. You can print these QR codes on menus, restaurant tables, flyers, business cards, merchandise, and retail packages for commercial business use forever.",
    },
  ];

  const handleToggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div id="faq-section" className="relative w-full max-w-4xl mx-auto">
      {/* Background Blobs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full bg-emerald-500/5 blur-[100px] pointer-events-none" />

      {/* Hero */}
      <div className="text-center mb-12">
        <span className="text-xs font-mono font-bold tracking-widest text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full uppercase">
          💬 FAQ Support
        </span>
        <h2 className={`font-display font-bold text-3xl sm:text-4xl mt-3.5 tracking-tight ${
          theme === "dark" ? "text-white" : "text-slate-900"
        }`}>
          Frequently Asked Questions
        </h2>
        <p className={`text-sm sm:text-base mt-2 max-w-lg mx-auto ${
          theme === "dark" ? "text-slate-400" : "text-slate-600"
        }`}>
          Got questions? We've got simple, transparent answers. No marketing fluff.
        </p>
      </div>

      {/* Accordions */}
      <div className="flex flex-col gap-4">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className={`border rounded-2xl transition-all duration-200 backdrop-blur-sm overflow-hidden ${
                theme === "dark"
                  ? isOpen
                    ? "border-emerald-500/50 shadow-lg shadow-emerald-950/15 bg-slate-900/60"
                    : "border-slate-800/80 hover:border-slate-700 bg-slate-900/40"
                  : isOpen
                    ? "border-emerald-500 bg-white shadow-lg shadow-slate-200/40"
                    : "border-slate-200 hover:border-slate-300 bg-white/60"
              }`}
            >
              <motion.button
                onClick={() => handleToggle(idx)}
                whileHover={{ scale: 1.005 }}
                whileTap={{ scale: 0.995 }}
                className={`w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 cursor-pointer font-semibold text-sm sm:text-base transition-all ${
                  theme === "dark" ? "text-white" : "text-slate-900"
                }`}
              >
                <span className="font-display">{faq.question}</span>
                <span className={`shrink-0 p-1.5 rounded-lg border ${
                  theme === "dark"
                    ? "bg-slate-950 border-slate-800 text-slate-400"
                    : "bg-slate-50 border-slate-200 text-slate-600"
                }`}>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-emerald-500" /> : <ChevronDown className="w-4 h-4" />}
                </span>
              </motion.button>

              <div
                className={`transition-all duration-300 ease-in-out overflow-hidden ${
                  isOpen
                    ? theme === "dark"
                      ? "max-h-60 border-t border-slate-800/60 p-5 sm:p-6 bg-slate-950/20"
                      : "max-h-60 border-t border-slate-100 p-5 sm:p-6 bg-slate-50/50"
                    : "max-h-0"
                }`}
              >
                <p className={`text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                  theme === "dark" ? "text-slate-400" : "text-slate-600"
                }`}>
                  {faq.answer}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Trust Signoff */}
      <div className={`mt-12 p-6 rounded-2xl flex items-center gap-4.5 max-w-2xl mx-auto border ${
        theme === "dark"
          ? "bg-slate-900/30 border-slate-800 text-slate-400"
          : "bg-white border-slate-200 text-slate-600 shadow-sm"
      }`}>
        <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-500 shrink-0">
          <Shield className="w-5 h-5" />
        </div>
        <div className="text-left text-xs leading-relaxed">
          <span className={`font-bold block mb-0.5 ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            Still have questions?
          </span>
          Email our community maintainers or hit us up on GitHub. We are a community-centric platform built on transparency and open source paradigms.
        </div>
      </div>
    </div>
  );
}
