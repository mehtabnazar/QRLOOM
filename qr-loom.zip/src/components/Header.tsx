import { useState, useEffect } from "react";
import { QrCode, Menu, X, Github, Instagram, Sun, Moon, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Logo from "./Logo";

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  theme: "dark" | "light";
  setTheme: (theme: "dark" | "light") => void;
}

export default function Header({ currentPage, setCurrentPage, theme, setTheme }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "QR Generator" },
    { id: "pdf", label: "PDF Tools" },
    { id: "features", label: "Features & SEO" },
    { id: "faq", label: "FAQ" },
    { id: "contact", label: "Contact" },
  ];

  return (
    <header
      id="main-header"
      className={`fixed left-1/2 -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-7xl transition-all duration-300 px-4 sm:px-6 lg:px-8 py-3 rounded-2xl border backdrop-blur-md shadow-lg ${
        isScrolled ? "top-3" : "top-5"
      } ${
        theme === "dark"
          ? "bg-slate-950/80 border-slate-800/80 shadow-slate-950/40"
          : "bg-white/85 border-slate-200/95 shadow-slate-200/20"
      }`}
    >
      <div className="flex items-center justify-between">
        {/* Logo */}
        <Logo
          theme={theme}
          onClick={() => {
            setCurrentPage("home");
            setIsMobileMenuOpen(false);
          }}
        />

        {/* Desktop Navigation */}
        <nav className={`hidden md:flex items-center gap-1.5 p-1 rounded-full border backdrop-blur-sm ${
          theme === "dark"
            ? "bg-slate-950/60 border-slate-800/60"
            : "bg-slate-100/80 border-slate-200/80"
        }`}>
          {navItems.map((item) => (
            <motion.button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 cursor-pointer ${
                currentPage === item.id
                  ? "bg-emerald-500 text-slate-950 font-bold shadow-sm shadow-emerald-500/10"
                  : theme === "dark"
                    ? "text-slate-400 hover:text-white hover:bg-slate-800/35"
                    : "text-slate-600 hover:text-slate-950 hover:bg-slate-200/60"
              }`}
            >
              {item.label}
            </motion.button>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="hidden md:flex items-center gap-3">
          {/* Theme Switcher */}
          <motion.button
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            whileHover={{ scale: 1.1, rotate: 15 }}
            whileTap={{ scale: 0.9, rotate: -15 }}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              theme === "dark"
                ? "bg-slate-900/80 hover:bg-slate-800 text-amber-400 border-slate-800/80"
                : "bg-slate-100 hover:bg-slate-200 text-indigo-600 border-slate-200/80"
            }`}
            title={theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </motion.button>

          {/* Unlimited Free Badge */}
          <span className="text-[10px] font-mono tracking-wider text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg uppercase font-bold flex items-center gap-1.5 shadow-sm">
            <Sparkles className="w-3 h-3 text-emerald-400 animate-pulse" />
            Completely Free & Unlimited
          </span>
        </div>

        {/* Mobile Actions Container (Theme toggle + hamburger) */}
        <div className="flex items-center gap-2 md:hidden">
          {/* Mobile Theme Switcher */}
          <motion.button
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            whileHover={{ scale: 1.1, rotate: 10 }}
            whileTap={{ scale: 0.9, rotate: -10 }}
            className={`p-2 rounded-lg border transition-all cursor-pointer ${
              theme === "dark"
                ? "bg-slate-900 text-amber-400 border-slate-800"
                : "bg-slate-100 text-indigo-600 border-slate-200"
            }`}
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </motion.button>

          {/* Mobile Menu Button */}
          <motion.button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className={`p-2 rounded-lg border transition-all ${
              theme === "dark"
                ? "text-slate-400 hover:text-white hover:bg-slate-800/60 border-slate-800"
                : "text-slate-600 hover:text-slate-900 hover:bg-slate-100 border-slate-200"
            }`}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </motion.button>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            className="md:hidden border-t border-slate-800/10 mt-3 overflow-hidden"
          >
            <div className={`border rounded-2xl p-4 mt-2 flex flex-col gap-2.5 shadow-xl ${
              theme === "dark"
                ? "bg-slate-950/95 border-slate-800/80 text-white"
                : "bg-white border-slate-200/90 text-slate-900"
            }`}>
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    currentPage === item.id
                      ? "bg-emerald-500 text-slate-950 font-bold"
                      : theme === "dark"
                        ? "text-slate-300 hover:text-white hover:bg-slate-800/40"
                        : "text-slate-600 hover:text-slate-950 hover:bg-slate-100"
                  }`}
                >
                  {item.label}
                </button>
              ))}

              <div className={`border-t my-2 pt-3 flex flex-col gap-2.5 ${
                theme === "dark" ? "border-slate-800/80" : "border-slate-100"
              }`}>
                <div className="flex items-center justify-between text-xs px-4">
                  <span className={theme === "dark" ? "text-slate-400" : "text-slate-500"}>Generation Fee</span>
                  <span className="text-emerald-500 font-bold tracking-wider">100% FREE & UNLIMITED</span>
                </div>
                <div className="flex gap-2 justify-center py-1">
                  <a
                    href="https://github.com/QR-LOOM"
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
                      theme === "dark"
                        ? "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800"
                        : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                    }`}
                  >
                    GitHub
                  </a>
                  <a
                    href="https://www.instagram.com/qrloom_official"
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
                      theme === "dark"
                        ? "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800"
                        : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                    }`}
                  >
                    Instagram
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
