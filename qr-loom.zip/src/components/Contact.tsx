import React, { useState } from "react";
import { Mail, MessageSquare, MapPin, Instagram, Linkedin, Github, Send, Check, Globe } from "lucide-react";
import { motion } from "motion/react";

interface ContactProps {
  theme?: "dark" | "light";
}

export default function Contact({ theme = "dark" }: ContactProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) {
      setFormError("All fields are required. Please fill them out.");
      return;
    }
    setFormError("");
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setName("");
      setEmail("");
      setMessage("");
      setTimeout(() => setIsSubmitted(false), 5000);
    }, 900); // Improved timing: faster submission feedback
  };

  return (
    <div id="contact-section" className="relative w-full">
      {/* Background Blobs */}
      <div className="absolute top-1/3 -right-16 w-80 h-80 rounded-full bg-emerald-500/5 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/4 -left-16 w-80 h-80 rounded-full bg-teal-500/5 blur-[110px] pointer-events-none animate-pulse" />

      {/* Hero */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-mono font-bold tracking-widest text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full uppercase">
          ✉️ Support Hub
        </span>
        <h2 className={`font-display font-bold text-3xl sm:text-4xl mt-3.5 tracking-tight ${
          theme === "dark" ? "text-white" : "text-slate-900"
        }`}>
          Get in Touch
        </h2>
        <p className={`text-sm sm:text-base mt-2 max-w-md mx-auto ${
          theme === "dark" ? "text-slate-400" : "text-slate-600"
        }`}>
          Need custom API integrations, enterprise white-label solutions, or help? Ask us anything!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start max-w-5xl mx-auto">
        {/* Left column: Contact Form */}
        <div className={`md:col-span-7 border p-6 sm:p-8 rounded-3xl backdrop-blur-md shadow-xl transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/50 border-slate-800/80 shadow-slate-950/20"
            : "bg-white border-slate-200/90 shadow-slate-200/30"
        }`}>
          <h3 className={`font-display font-bold text-lg mb-6 flex items-center gap-2 ${
            theme === "dark" ? "text-white" : "text-slate-900"
          }`}>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Send a Secure Message
          </h3>

          {formError && (
            <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-semibold">
              ⚠️ {formError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-5 text-xs sm:text-sm">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Your Name</label>
                <motion.input
                  type="text"
                  required
                  placeholder="e.g. Syed Mehtab"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  whileHover={{ scale: 1.015, borderColor: "#10b981" }}
                  whileFocus={{ scale: 1.015 }}
                  transition={{ duration: 0.2 }}
                  className={`border rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all ${
                    theme === "dark"
                      ? "bg-slate-950/60 border-slate-800 text-white"
                      : "bg-slate-50 border-slate-200 text-slate-900"
                  }`}
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Email Address</label>
                <motion.input
                  type="email"
                  required
                  placeholder="your.email@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  whileHover={{ scale: 1.015, borderColor: "#10b981" }}
                  whileFocus={{ scale: 1.015 }}
                  transition={{ duration: 0.2 }}
                  className={`border rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all ${
                    theme === "dark"
                      ? "bg-slate-950/60 border-slate-800 text-white"
                      : "bg-slate-50 border-slate-200 text-slate-900"
                  }`}
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Detailed Message</label>
              <motion.textarea
                required
                rows={5}
                placeholder="How can our open-source studio assist your business?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                whileHover={{ scale: 1.015, borderColor: "#10b981" }}
                whileFocus={{ scale: 1.015 }}
                transition={{ duration: 0.2 }}
                className={`border rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-none ${
                  theme === "dark"
                    ? "bg-slate-950/60 border-slate-800 text-white"
                    : "bg-slate-50 border-slate-200 text-slate-900"
                }`}
              />
            </div>

            <motion.button
              type="submit"
              disabled={isSubmitting}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: "spring", stiffness: 400, damping: 15 }}
              className="py-3 px-6 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-sm rounded-xl shadow-lg shadow-emerald-500/10 flex items-center justify-center gap-2 transition-all cursor-pointer mt-2"
            >
              {isSubmitting ? (
                <>Processing...</>
              ) : isSubmitted ? (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  Message Transmitted!
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Transmit Message
                </>
              )}
            </motion.button>
          </form>
        </div>

        {/* Right column: Info & Social links */}
        <div className="md:col-span-5 flex flex-col gap-6">
          {/* Info Card */}
          <div className={`border p-6 rounded-3xl backdrop-blur-md flex flex-col gap-4 transition-all duration-300 ${
            theme === "dark"
              ? "bg-slate-900/40 border-slate-800/80"
              : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h3 className={`font-display font-bold text-xs uppercase tracking-wider pb-2 border-b ${
              theme === "dark" ? "text-slate-300 border-slate-800/60" : "text-slate-800 border-slate-100"
            }`}>
              Support Coordinates
            </h3>

            <div className="flex flex-col gap-4.5 text-xs sm:text-sm">
              <div className="flex items-start gap-3.5">
                <div className={`w-9 h-9 rounded-xl border flex items-center justify-center text-emerald-500 shrink-0 ${
                  theme === "dark" ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-100"
                }`}>
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className={`text-[10px] font-bold uppercase tracking-wider block ${
                    theme === "dark" ? "text-slate-500" : "text-slate-400"
                  }`}>
                    Location
                  </span>
                  <span className={`font-medium leading-relaxed ${
                    theme === "dark" ? "text-slate-200" : "text-slate-800"
                  }`}>
                    San Francisco, CA
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className={`w-9 h-9 rounded-xl border flex items-center justify-center text-emerald-500 shrink-0 ${
                  theme === "dark" ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-100"
                }`}>
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <span className={`text-[10px] font-bold uppercase tracking-wider block ${
                    theme === "dark" ? "text-slate-500" : "text-slate-400"
                  }`}>
                    Official Website
                  </span>
                  <a href="https://www.mehtabnazar.xyz" target="_blank" rel="noopener noreferrer" className={`font-medium transition-colors ${
                    theme === "dark" ? "text-slate-200 hover:text-emerald-400" : "text-slate-800 hover:text-emerald-600"
                  }`}>
                    www.mehtabnazar.xyz
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Social Links Cards */}
          <div className={`border p-6 rounded-3xl backdrop-blur-md flex flex-col gap-3.5 transition-all duration-300 ${
            theme === "dark"
              ? "bg-slate-900/40 border-slate-800/80"
              : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h3 className={`font-display font-bold text-xs uppercase tracking-wider pb-2 border-b ${
              theme === "dark" ? "text-slate-300 border-slate-800/60" : "text-slate-800 border-slate-100"
            }`}>
              Official Communities
            </h3>

            <div className="flex flex-col gap-2.5">
              <a
                href="https://www.instagram.com/qrloom_official"
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center justify-between p-3 rounded-xl border transition-all group cursor-pointer ${
                  theme === "dark"
                    ? "bg-slate-950/65 border-slate-900 hover:border-emerald-500/40 hover:bg-slate-950"
                    : "bg-slate-50 border-slate-100 hover:border-emerald-500/30 hover:bg-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-pink-500/10 border border-pink-500/20 flex items-center justify-center text-pink-500 group-hover:rotate-12 transition-transform">
                    <Instagram className="w-4.5 h-4.5" />
                  </div>
                  <span className={`text-xs font-semibold group-hover:text-emerald-500 transition-colors ${
                    theme === "dark" ? "text-slate-200" : "text-slate-800"
                  }`}>
                    Instagram
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">@qrloom_official</span>
              </a>

              <a
                href="https://github.com/QR-LOOM"
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center justify-between p-3 rounded-xl border transition-all group cursor-pointer ${
                  theme === "dark"
                    ? "bg-slate-950/65 border-slate-900 hover:border-emerald-500/40 hover:bg-slate-950"
                    : "bg-slate-50 border-slate-100 hover:border-emerald-500/30 hover:bg-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 group-hover:rotate-12 transition-transform">
                    <Github className="w-4.5 h-4.5" />
                  </div>
                  <span className={`text-xs font-semibold group-hover:text-emerald-500 transition-colors ${
                    theme === "dark" ? "text-slate-200" : "text-slate-800"
                  }`}>
                    GitHub Org
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">/QR-LOOM</span>
              </a>

              <a
                href="https://www.linkedin.com/company/qr-loom"
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center justify-between p-3 rounded-xl border transition-all group cursor-pointer ${
                  theme === "dark"
                    ? "bg-slate-950/65 border-slate-900 hover:border-emerald-500/40 hover:bg-slate-950"
                    : "bg-slate-50 border-slate-100 hover:border-emerald-500/30 hover:bg-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 group-hover:rotate-12 transition-transform">
                    <Linkedin className="w-4.5 h-4.5" />
                  </div>
                  <span className={`text-xs font-semibold group-hover:text-emerald-500 transition-colors ${
                    theme === "dark" ? "text-slate-200" : "text-slate-800"
                  }`}>
                    LinkedIn Company
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">/company/qr-loom</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
