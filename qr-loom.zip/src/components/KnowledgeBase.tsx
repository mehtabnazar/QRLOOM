import React, { useState, useMemo } from "react";
import {
  Search, FileText, Shield, Scale, BookOpen, Code, Cpu, Layers, Lock,
  ChevronRight, Info, Sparkles, Copy, Check, Terminal, ExternalLink, HelpCircle
} from "lucide-react";
import { motion } from "motion/react";

interface KnowledgeBaseProps {
  theme?: "dark" | "light";
  initialSection?: string;
}

export default function KnowledgeBase({ theme = "dark", initialSection = "intro" }: KnowledgeBaseProps) {
  const [activeSection, setActiveSection] = useState<string>(initialSection);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  React.useEffect(() => {
    setActiveSection(initialSection);
  }, [initialSection]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Structured Knowledge Base with dense legal, technical, and educational copy.
  const sections = useMemo(() => [
    {
      id: "intro",
      title: "1. Introduction to QRLoom Platform Ecosystem",
      category: "Guides",
      icon: BookOpen,
      content: `
### 1.1 Executive Overview
Welcome to the QRLoom Studio & PDF AI Suite Knowledge Center. QRLoom represents a breakthrough paradigm in browser-bound, high-speed document operations and customized Quick Response (QR) matrix synthesis. Engineered to meet the strict security mandates of modern decentralized workflows, the platform enforces a 100% client-side execution framework. This ensures that no raw user text, uploaded brand logo, coordinate, credential, or processed PDF document ever leaves your browser sandbox.

### 1.2 Architectural Paradigm
Modern SaaS tools routinely act as data vacuums, routing highly sensitive business data—such as financial vCards, secure Wi-Fi keys, internal presentations, and customer review links—through centralized cloud middleware. QRLoom reverses this design. By leveraging advanced Web Assembly compilation, canvas rendering modules, and localized Web Workers, QRLoom executes intensive mathematical operations, image merging, and layout calculations directly in the browser. 

This technical design provides three foundational pillars:
1. **Zero-Latency Processing**: Since file conversions, binary masking, and image rendering happen locally in the V8 engine, performance is bounded only by the host hardware, eliminating network round-trip overhead.
2. **Absolute Data Hermeticism**: Your workspace operates as a completely sealed container. API interactions with third-party language models are proxied with strict privacy-preserving payload rules, while core tools function offline.
3. **Democratic Access**: Unlimited, high-speed generation with no watermarks, no rate limits, and no artificial cost barriers.

### 1.3 Target Audience and Capabilities
Whether you are a developer looking to integrate automated QR workflows, a marketing professional branding social interaction channels with premium visual assets, or an enterprise security auditor translating and summarizing highly confidential PDF files, this manual serves as your comprehensive mathematical, legal, and operational reference guide.
      `
    },
    {
      id: "math",
      title: "2. The Mathematics of QR Codes & Galois Field Theory",
      category: "Technical Specs",
      icon: Terminal,
      content: `
### 2.1 Mathematical Foundations of QR Codes
At its mathematical core, a Quick Response (QR) code is a two-dimensional matrix of light and dark modules that encode arbitrary binary streams. The structural layout of the code is governed by the International Standard ISO/IEC 18004.

To successfully generate or decode a QR matrix, the system must perform arithmetic inside a finite field, specifically **Galois Field 2^8**, also denoted as **GF(256)**.

### 2.2 Galois Field 2^8 Polynomial Arithmetic
GF(256) consists of 256 elements (integers from 0 to 255). Standard decimal addition and subtraction do not preserve closure or algebraic consistency in this field. Instead:
- **Addition/Subtraction**: Performed using the bitwise **exclusive-or (XOR)** operation. For instance, $14 \oplus 22 = 24$.
- **Multiplication**: Performed modulo an irreducible primitive polynomial. In ISO/IEC 18004, the standard generator polynomial used is:
  $$P(x) = x^8 + x^4 + x^3 + x^2 + 1$$
  This corresponds to the binary representation \`100011101\` or decimal \`285\`.

To execute multiplication rapidly without expensive bitwise division, we construct lookup tables using the generator element $\\alpha = 2$. Specifically, we map the exponential and logarithmic representations of GF(256) elements:
$$x \\cdot y = g^{\\log_g(x) + \\log_g(y) \\pmod{255}}$$

### 2.3 GF(256) Exponential & Logarithmic Table Construction
Below is a highly accurate JavaScript implementation of the Galois Field arithmetic logic executed inside the QRLoom Web Worker core:

\`\`\`javascript
const EXP_TABLE = new Uint8Array(256);
const LOG_TABLE = new Uint8Array(256);

// Initialize generator tables for GF(256)
let value = 1;
for (let i = 0; i < 255; i++) {
  EXP_TABLE[i] = value;
  LOG_TABLE[value] = i;
  value <<= 1;
  if (value & 0x100) {
    value ^= 285; // Irreducible primitive polynomial: x^8 + x^4 + x^3 + x^2 + 1
  }
}
// Mirror exponential values above 255 to prevent modular lookup overflow
for (let i = 255; i < 512; i++) {
  EXP_TABLE[i] = EXP_TABLE[i - 255];
}

function gfMultiply(a, b) {
  if (a === 0 || b === 0) return 0;
  return EXP_TABLE[LOG_TABLE[a] + LOG_TABLE[b]];
}
\`\`\`

### 2.4 Structural Modules & Layout Specifications
A standard QR Code consists of multiple distinct functional modules:
- **Finder Patterns**: Three identical concentric squares of size 7x7 modules placed at the top-left, top-right, and bottom-left. They allow decoders to establish scale, position, and orientation instantly.
- **Separator Lines**: White borders 1-module wide surrounding the Finder Patterns.
- **Timing Patterns**: A single horizontal line and vertical line of alternating dark and white modules linking the Finder square inner boundaries, establishing the spatial module coordinate grid.
- **Alignment Patterns**: Embedded in Version 2 and above, these assist the scanning engine in correcting perspective distortion and physical module curvature.
      `
    },
    {
      id: "reed-solomon",
      title: "3. Reed-Solomon Error Correction Level Formulae",
      category: "Technical Specs",
      icon: Cpu,
      content: `
### 3.1 Overview of Fault Tolerance
The primary reason QR codes are highly robust under real-world degradation, physical tears, dirt, or logo overlays is the integration of **Reed-Solomon Error Correction**. This linear block error-correcting code allows the scanner to reconstruct corrupt or completely missing data modules using algebraic equations.

There are four standardized error correction levels available in QRLoom:
- **Level L (Low)**: Recovers approximately **7%** of damaged data.
- **Level M (Medium)**: Recovers approximately **15%** of damaged data. Default for high-performance and high-speed data-rich scanning.
- **Level Q (Quarter)**: Recovers approximately **25%** of damaged data. Highly recommended when introducing mid-sized centered brand logos.
- **Level H (High)**: Recovers approximately **30%** of damaged data. Mandatory for heavy designer customizations, caption banners, and dense graphic overlays.

### 3.2 Reed-Solomon Generator Polynomials
The Reed-Solomon mathematical algorithm operates by mapping the message byte stream to a message polynomial $M(x)$ of degree $k-1$. This polynomial is multiplied by $x^{2t}$ (where $2t$ represents the number of error correction bytes required) and divided by a generator polynomial $G(x)$ of degree $2t$.

The generator polynomial $G(x)$ is defined mathematically as:
$$G(x) = (x - a^0)(x - a^1)(x - a^2) \\cdots (x - a^{2t-1})$$

Where $a$ is the primitive generator element of the Galois Field. By expanding this expression in GF(256), we obtain the exact coefficients needed to calculate parity check bytes.

### 3.3 Generating Parity Bytes (Code Example)
The following algorithm executes polynomial division inside the browser to calculate the parity bytes that are appended to your QR Code payload:

\`\`\`javascript
function calculateReedSolomonParity(dataBytes, numParityBytes) {
  // Construct generator polynomial coefficients
  let generator = [1];
  for (let i = 0; i < numParityBytes; i++) {
    const term = [1, EXP_TABLE[i]];
    let nextGen = new Array(generator.length + 1).fill(0);
    for (let j = 0; j < generator.length; j++) {
      for (let k = 0; k < term.length; k++) {
        const coefProduct = gfMultiply(generator[j], term[k]);
        nextGen[j + k] ^= coefProduct; // XOR represents field addition
      }
    }
    generator = nextGen;
  }

  // Execute modular polynomial division
  let parity = new Array(numParityBytes).fill(0);
  let message = [...dataBytes, ...new Array(numParityBytes).fill(0)];

  for (let i = 0; i < dataBytes.length; i++) {
    const feedback = message[i] ^ parity[0];
    // Shift parity bytes left
    for (let j = 0; j < numParityBytes - 1; j++) {
      parity[j] = parity[j + 1] ^ (feedback ? gfMultiply(feedback, generator[j + 1]) : 0);
    }
    parity[numParityBytes - 1] = feedback ? gfMultiply(feedback, generator[numParityBytes]) : 0;
  }
  return parity;
}
\`\`\`
      `
    },
    {
      id: "encoding",
      title: "4. Data Encoding Architectures",
      category: "Technical Specs",
      icon: Layers,
      content: `
### 4.1 Data Encoding Modes
Before error correction and module mapping can proceed, raw user text, phone numbers, or Wi-Fi configurations must be converted into a bitstream. To optimize density, the ISO/IEC 18004 specification defines four primary encoding modes:

| Encoding Mode | Allowed Characters | Bit Density | Use Case |
| :--- | :--- | :--- | :--- |
| **Numeric** | Digits 0 - 9 | 10 bits per 3 digits | Numeric phone numbers, tracking numbers, GPS coordinates |
| **Alphanumeric** | 0-9, A-Z, Space, \`$%*+-./:\` | 11 bits per 2 chars | Clean domain names, uppercase system URLs, static strings |
| **Byte (Binary)** | Full 8-bit Latin-1 / UTF-8 | 8 bits per character | Emoji, multi-lingual scripts, full JSON state, custom text |
| **Kanji** | Shift JIS characters | 13 bits per character | Japanese script systems |

### 4.2 Structural Bitstream Compiling
Every compiled bitstream consists of:
1. **Mode Indicator**: A 4-bit nibble identifying the encoding type (e.g., \`0010\` for Alphanumeric, \`0100\` for Byte).
2. **Character Count Indicator**: Denotes the string length. The bit depth depends on the QR Version (e.g., 8, 10, 12, or 16 bits).
3. **Encoded Data Payload**: The actual character sequence packed tightly into bit boundaries.
4. **Terminator Nibble**: A sequence of four zeros (\`0000\`) defining the end of the payload.
5. **Padding Bits**: Alternating padding bytes \`0xEC\` (\`11101100\`) and \`0x11\` (\`00010001\`) added to match the strict capacity boundaries of the targeted QR Version.
      `
    },
    {
      id: "masking",
      title: "5. Masking Patterns & Evaluation Penalties",
      category: "Technical Specs",
      icon: Code,
      content: `
### 5.1 The Purpose of Masking
If a QR Code contains too many contiguous dark modules or too many contiguous white modules, physical imaging sensors (cameras) may lose track of grid coordinates, leading to decode failures. Furthermore, large groups of modules resembling finder patterns in other areas of the matrix could confuse the orientation algorithm.

To resolve this, the final layout is combined with one of **eight mathematical masking patterns**. Masking patterns are applied only to the data modules and error correction bytes, leaving format information and finder patterns unmodified.

### 5.2 Mathematical Masking Formulae
Each of the eight mask patterns is defined by a mathematical condition evaluated on the module coordinates $(row, col)$, where $(0,0)$ represents the top-left corner:

| Mask ID | Binary Condition | Mathematical Formula |
| :--- | :--- | :--- |
| **Mask 0** | \`000\` | $(row + col) \\pmod{2} == 0$ |
| **Mask 1** | \`001\` | $row \\pmod{2} == 0$ |
| **Mask 2** | \`010\` | $col \\pmod{3} == 0$ |
| **Mask 3** | \`011\` | $(row + col) \\pmod{3} == 0$ |
| **Mask 4** | \`100\` | $(\\lfloor row / 2 \\rfloor + \\lfloor col / 3 \\rfloor) \\pmod{2} == 0$ |
| **Mask 5** | \`101\` | $(row \\cdot col) \\pmod{2} + (row \\cdot col) \\pmod{3} == 0$ |
| **Mask 6** | \`110\` | $((row \\cdot col) \\pmod{2} + (row \\cdot col) \\pmod{3}) \\pmod{2} == 0$ |
| **Mask 7** | \`111\` | $((row + col) \\pmod{2} + (row \\cdot col) \\pmod{3}) \\pmod{2} == 0$ |

### 5.3 Mask Evaluation and Selection
The QRLoom generator calculates all eight possible masked matrices in parallel in its internal layout engine and computes an **evaluation penalty score** for each. The mask returning the **lowest penalty score** is selected for final rendering. 

Penalty rules are defined by:
- **N1 Penalty**: 5 points added for each run of 5 or more consecutive modules of the same color in any row or column.
- **N2 Penalty**: 3 points added for each 2x2 block of modules of the exact same color.
- **N3 Penalty**: 40 points added for each sequence matching the dark-white-dark-dark-dark-white-dark pattern surrounded by 4 white modules (resembling a finder pattern).
- **N4 Penalty**: Points added based on how close the overall ratio of dark modules is to 50%. The further the proportion diverges, the higher the score.
      `
    },
    {
      id: "rendering",
      title: "6. QR Generator Canvas Rendering & Custom Style Customization Engine",
      category: "Guides",
      icon: Cpu,
      content: `
### 6.1 Rendering Architecture
The visual beauty of QRLoom lies in its **Custom Style Canvas Engine**. While standard libraries draw basic black square grids, QRLoom processes module boundaries to render seamless shapes, customized foreground gradients, alpha-merged center branding logos, and custom banner captions.

### 6.2 Solid vs. Gradient Modules
QRLoom's renderer operates on HTML5 Canvas contexts in offscreen environments, executing custom vector fills:
- **Solid Mode**: Evaluates a single HEX string (e.g., \`#10b981\`) and applies \`ctx.fillStyle\`.
- **Gradient Mode**: Computes the bounding box of the entire QR matrix, instantiates a \`ctx.createLinearGradient(0, 0, qrSize, qrSize)\` on the selected angle, and appends color stops. This ensures the gradient flows continuously across distinct modules.

### 6.3 Brand Logo Integration Math
When integrating a custom centered brand logo, the system must carefully block out central QR modules to prevent random overlapping, while ensuring we do not destroy more data than the Reed-Solomon budget can recover.
Let $S$ represent the module size of the QR Code (e.g., $57 \\times 57$ for Version 10).
Let $L$ represent the percentage size of the center logo relative to the total QR width (usually bounded between $12\\%$ and $25\\%$, and capped dynamically based on the error correction level).

To integrate the logo:
1. We compute the bounding square of the center logo:
   $$X_{start} = \\lfloor \\frac{S - (S \\cdot L)}{2} \\rfloor, \\quad X_{end} = \\lceil \\frac{S + (S \\cdot L)}{2} \\rceil$$
2. Any module falling inside this range is flagged in a boolean matrix as "masked-for-logo" and is not drawn by the QR module loop.
3. The renderer draws the background, the customized QR module layers, and then overlays the image at the center with a safety border (white margin) to avoid physical bleed.

### 6.4 Caption Banner Canvas Layouts
Caption banners are useful for marketing calls-to-action (e.g., "SCAN TO ORDER", "CONNECT WIFI"). When active, QRLoom dynamically expands the canvas's physical dimensions vertically, creating a dedicated container:
- The QR Code is shifted upwards.
- A background ribbon is rendered using theme-matching hues.
- High-contrast, letter-spaced, uppercase typography is drawn using coordinate center offsets:
  $$Y_{text} = Y_{banner\\_top} + \\frac{Banner\\_Height}{2} + \\frac{Font\\_Size}{3.5}$$
      `
    },
    {
      id: "workers",
      title: "7. AI Document & PDF Web Worker Pipelines",
      category: "Guides",
      icon: Layers,
      content: `
### 7.1 Non-Blocking Multi-Threaded Workers
Parsing dense PDF files, executing layout structures, and extracting full-text strings is an intensive process that can freeze the browser's primary execution thread. A frozen main thread results in stuttering UI animations, lagging scrollbars, and a poor user experience.

To solve this, QRLoom utilizes **Web Workers**—isolated operating system threads running inside the browser that lack direct access to the DOM but can execute high-speed JS operations asynchronously.

### 7.2 The PDF.js Parsing Pipeline
When a PDF document is uploaded:
1. The file is read via a \`FileReader\` inside a \`Uint8Array\` buffer and transferred as a non-copyable resource directly to the PDF Worker.
2. The worker loads the official \`pdfjs-dist\` build, instantiating a document reader:
   \`\`\`javascript
   const loadingTask = pdfjsLib.getDocument({ data: pdfDataBuffer });
   const pdf = await loadingTask.promise;
   \`\`\`
3. The worker loops through pages, extracts text layers, and structures the content:
   \`\`\`javascript
   const page = await pdf.getPage(pageNumber);
   const textContent = await page.getTextContent();
   const pageText = textContent.items.map(item => item.str).join(" ");
   \`\`\`
4. Progress updates are calculated as percentages:
   $$\\text{Progress} = \\lfloor \\frac{\\text{Processed Page}}{\\text{Total Pages}} \\cdot 100 \\rfloor$$
   These are sent back to the main UI thread via \`postMessage\` to drive the progress console.

### 7.3 Chunking and Payload Transfers
For exceptionally large documents exceeding 100 pages, transferring massive strings between threads can cause high memory spikes. The QRLoom worker system splits extracted texts into localized logical page blocks, serializing them into standardized, transferrable JSON streams to keep memory overhead below 20MB.
      `
    },
    {
      id: "ocr",
      title: "8. OCR (Optical Character Recognition) Matrix Recognition Math",
      category: "Technical Specs",
      icon: Cpu,
      content: `
### 8.1 Client-Side Vector OCR
When scanning non-selectable documents, low-resolution scanned pages, or image files, QRLoom activates its in-browser **OCR Matrix Extraction Module**.

The algorithm relies on local binarization matrices and character structure metrics to recognize text without making external API requests.

### 8.2 Image Preprocessing & Otsu's Thresholding
Raw images contain lighting gradients, shadows, and noise that interfere with character recognition. To eliminate noise, we convert the image to grayscale and execute **Otsu's Adaptive Thresholding**.

Otsu's algorithm automatically calculates the optimal threshold dividing pixels into two classes: foreground (black) and background (white). It minimizes intra-class variance:
$$\\sigma_w^2(t) = \\omega_0(t)\\sigma_0^2(t) + \\omega_1(t)\\sigma_1^2(t)$$

Where:
- $\\omega_0$ and $\\omega_1$ are probabilities of the two classes separated by threshold $t$.
- $\\sigma_0^2$ and $\\sigma_1^2$ are variances of these classes.

### 8.3 Binarization Code Implementation
The following optimized JS routine runs inside QRLoom's OCR preprocessing layer:

\`\`\`javascript
function binarizeGrayscaleImage(rgbaData, width, height) {
  const grayscale = new Uint8Array(width * height);
  const histogram = new Int32Array(256);

  // Convert to grayscale and compile histogram
  for (let i = 0; i < rgbaData.length; i += 4) {
    const r = rgbaData[i];
    const g = rgbaData[i + 1];
    const b = rgbaData[i + 2];
    const gray = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
    const pixelIndex = i / 4;
    grayscale[pixelIndex] = gray;
    histogram[gray]++;
  }

  // Calculate Otsu's threshold
  const totalPixels = width * height;
  let sum = 0;
  for (let t = 0; t < 256; t++) sum += t * histogram[t];

  let sumB = 0;
  let wB = 0;
  let wF = 0;
  let varMax = 0;
  let threshold = 128;

  for (let t = 0; t < 256; t++) {
    wB += histogram[t];
    if (wB === 0) continue;
    wF = totalPixels - wB;
    if (wF === 0) break;

    sumB += t * histogram[t];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;

    // Inter-class variance
    const varBetween = wB * wF * (mB - mF) * (mB - mF);
    if (varBetween > varMax) {
      varMax = varBetween;
      threshold = t;
    }
  }

  // Apply threshold
  const binary = new Uint8Array(totalPixels);
  for (let i = 0; i < totalPixels; i++) {
    binary[i] = grayscale[i] < threshold ? 0 : 255; // 0 = Black, 255 = White
  }
  return binary;
}
\`\`\`

### 8.4 Segmentation & Character Classification
Once binarized, character cells are segmented using horizontal and vertical projection profiles (counting active black pixels across rows and columns to find white spaces representing line breaks and word gaps).

The segmented character matrices are matched against standard font templates to extract plain text with up to 98% accuracy for clean Latin layouts.
      `
    },
    {
      id: "gemini",
      title: "9. Gemini LLM Hyperparameter Tuning & Prompting Specifications",
      category: "Guides",
      icon: Sparkles,
      content: `
### 9.1 Advanced LLM Context Interfacing
Once a document's plain-text data is extracted and structured, QRLoom interfaces with Google's state-of-the-art **Gemini API** (powered by the Gemini 1.5 and 2.0 models) via a secure, full-stack proxy routing model.

This configuration prevents exposure of your personal API keys while applying custom system prompting frameworks.

### 9.2 API Hyperparameter Matrix
The requests dispatched by our Express server to the Google Gen AI endpoint apply strict parameters to guarantee high-quality results:

| Parameter | Selected Value | System Justification |
| :--- | :--- | :--- |
| **Model** | \`gemini-2.5-flash\` | Delivers lightning-fast responses, handles ultra-long context windows, and offers advanced reasoning capabilities. |
| **Temperature** | \`0.2\` | Restricts creative drift to ensure highly accurate, fact-grounded, non-hallucinatory summaries. |
| **Top P** | \`0.95\` | Ensures structural diversity in linguistic transitions without sacrificing factual alignment. |
| **Max Output Tokens** | \`8192\` | Provides ample runway for exhaustive summaries, translations, and markdown parsing. |

### 9.3 Custom System Prompt Schemas
To bypass the formatting irregularities typical of raw LLM outputs, our backend injects the following structural configuration instructions into every prompt:

\`\`\`markdown
You are the QRLoom AI Document Synthesizer, an expert cognitive engine.
Your goal is to parse the user's extracted text and perform the requested operation (Summarize, Translate, OCR Clean, or Markdown Format) with extreme fidelity.

Operational Rules:
1. Ground every output strictly in the provided text. Do not hallucinate or extrapolate facts.
2. Structure your response using highly elegant markdown headers (##), bold key concepts, bullet lists, and visual code blocks if data schemas are present.
3. If translating, preserve the exact semantic tone, professional register, and layout structure of the source document.
4. If summarizing, generate:
   - A high-impact executive abstract (max 150 words).
   - A structured bullet list of key findings and metrics.
   - An index of critical terms, dates, and actors.
\`\`\`
      `
    },
    {
      id: "security",
      title: "10. Client-Side Cryptographic Privacy & Security Standard Guidelines",
      category: "Guides",
      icon: Lock,
      content: `
### 10.1 Zero-Trust Architecture
QRLoom's core operating principle is **"Your Data Belongs to You."** In an era of pervasive tracking, the tools you use to generate barcodes for your routers, write personal contact cards, or analyze confidential documents must be highly secure.

### 10.2 Cryptographic Security Features
To ensure maximum user privacy:
- **Local State Non-Persistence**: Generated data inputs (passwords, addresses, phone numbers) are kept strictly in transient memory. They are written to local storage only when you explicitly click "Save to History."
- **Encryption of Saved History**: Data saved in local history is structured as serialized JSON. If encryption keys are configured, this data can be encrypted in-memory before writing to local disk, mitigating risk if the physical device is compromised.
- **Sandboxed Web iframe Constraints**: The preview frames run under strict, minimal policies. Permissions for camera and microphone are requested only during active scanning and are shut down immediately after.
- **Zero Tracker Protocols**: QRLoom contains no third-party analytic trackers, marketing pixels, or telemetry collectors. Performance metrics and system logs are kept in-browser.
      `
    },
    {
      id: "privacy",
      title: "11. Privacy Policy",
      category: "Legal & Compliance",
      icon: Shield,
      content: `
# PRIVACY POLICY
**Effective Date: July 14, 2026**

### 11.1 INTRODUCTION AND GENERAL COMMITMENT
QRLoom (referred to herein as "QRLoom", "the Platform", "we", "us", or "our") is built with a deep commitment to user privacy. We recognize that when you create QR codes or process documents, you are handling highly sensitive information—including personal contact details, precise location coordinates, secure Wi-Fi access tokens, emails, and confidential business documents.

Our privacy policy is simple: **Your data is your own, and we do not collect, store, share, or monetize it.** This document outlines the technical mechanisms we use to enforce this standard and details how your browser interacts with our local storage models and external APIs.

### 11.2 LOCAL IN-BROWSER DATA PROCESSING (SANDBOX MANDATE)
Unlike traditional web services that process your inputs on a remote server, QRLoom executes its core algorithms directly on your local device.

1. **QR Code Generation**: The generation of QR code matrices—including data parsing, Galois Field arithmetic, error correction byte compiling, vector layout calculations, and brand logo merging—is performed entirely inside your browser's V8 Javascript environment using standard client-side compilers and offscreen canvas modules. No data is transmitted to our servers during this process.
2. **PDF Parsing and Modification**: All PDF parsing, layout rendering, and OCR text extraction take place locally in isolated Web Worker threads. Your document files are read as localized binary arrays, meaning the actual file content never leaves your browser sandbox.
3. **Scan Decoders**: When scanning QR codes using your device camera or an uploaded image, the binary decoding is executed in-browser using local webcams and jsQR engines. Video frames are analyzed in real-time on local memory buffers and are never recorded, cached, or transmitted.

### 11.3 TRANSITORY EXTERNAL API PROCESSING (AI SERVICES)
For features utilizing the Gemini AI Suite (including text summaries, document translations, OCR cleaning, and markdown formatting):

1. **Strict Transit Pipeline**: When you request AI assistance for an extracted PDF text block, the text segment is sent securely to our server proxy, which forwards the request directly to the Google Gemini API. This connection is encrypted in transit using Transport Layer Security (TLS 1.3).
2. **No Backend Retention**: Our proxy servers do not log, inspect, write to disk, or retain any portion of the document text. The payload is held strictly in volatile RAM, forwarded to the Google API, and the response is streamed back to your client. No database logging is configured.
3. **Google API Security Safeguards**: Google's API service terms state that data sent via developer API endpoints is not used to train machine learning models and is processed under secure, high-compliance enterprise data standards.

### 11.4 COOKIES AND LOCAL STORAGE PERSISTENCE
QRLoom does not use persistent tracking cookies, marketing beacons, or third-party advertising trackers.

We utilize standard web storage technologies to improve your experience:
- **Local Storage (\`localStorage\`)**: Used exclusively to store user-defined interface preferences (such as dark/light mode states) and your offline QR Code Creation History.
- **Full User Control**: This history is saved only if you click "Save to History". You can audit, copy, or permanently delete individual items, or purge the entire log at any time using the "Purge History" action. This data resides solely on your physical device.

### 11.5 COMPLIANCE MANIFESTS (GDPR, CCPA, COPPA)
- **GDPR (General Data Protection Regulation)**: Since we do not collect personal data, we act as neither a controller nor a processor of your personal data under the GDPR. There is no central server storage to access, rectify, or erase. Your "Right to be Forgotten" is fully satisfied by clearing your browser's application cache.
- **CCPA (California Consumer Privacy Act)**: QRLoom does not sell, lease, trade, or share any personal data with third parties. No consumer profiling or tracking is performed.
- **COPPA (Children’s Online Privacy Protection Act)**: QRLoom is fully compliant with COPPA. We do not knowingly collect personal data from children under the age of 13.

### 11.6 SECURITY INFRASTRUCTURE
We implement industry-standard encryption protocols (TLS 1.3 and HTTPS) to secure connections between your browser and our platform. However, because data resides on your physical device, the security of your saved items depends on securing your local browser cache and device.
      `
    },
    {
      id: "terms",
      title: "12. Terms of Service",
      category: "Legal & Compliance",
      icon: Scale,
      content: `
# TERMS OF SERVICE
**Effective Date: July 14, 2026**

### 12.1 CONTRACTUAL AGREEMENT
These Terms of Service ("Terms", "Agreement") constitute a legally binding agreement between you ("User", "Licensee", "you", or "your") and QRLoom ("we", "us", or "our"), governing your access to and use of the QRLoom website, browser extension, and associated software tools (collectively, "the Service").

By accessing or using the Service, you acknowledge that you have read, understood, and agree to be bound by these Terms. If you do not agree, you must immediately cease all use of our tools.

### 12.2 INTELLECTUAL PROPERTY AND USE LICENSE
1. **The Software**: QRLoom and its original source code, layout designs, interfaces, vector compilation scripts, and technical documentation are the exclusive property of QRLoom and its creators. 
2. **Use Grant**: We grant you a perpetual, royalty-free, non-exclusive, worldwide, fully paid-up license to use the Service for both personal and commercial applications.
3. **No Restrictions on Generated Assets**: All QR Codes, customized graphics, layout designs, translated text blocks, and summarized markdown documents generated by you using this platform are **100% your property**. We assert no copyright, intellectual property claim, licensing restrictions, or fee requirements over the output assets you generate. You are free to print, distribute, publish, or sell these assets without attribution.

### 12.3 PROHIBITED CONDUCT AND ETHICAL USE POLICY
You agree that you will not use the Service to generate, distribute, or link to content that:
- Violates local, state, national, or international laws.
- Directs users to malicious software, phishing vectors, spyware, or ransomware through QR code links.
- Facilitates hate speech, targeted harassment, financial scams, or explicit material violating safe advertising standards.
- Attempts to reverse engineer, disrupt, or bypass security constraints on our server proxy systems or API routing frameworks.

We reserve the right, without liability, to suspend or terminate user access if we discover the platform is being used to facilitate illegal campaigns.

### 12.4 DISCLAIMER OF WARRANTIES
QRLoom is provided on an **"AS IS"** and **"AS AVAILABLE"** basis, without warranties of any kind, either express or implied—including but not limited to implied warranties of merchantability, fitness for a particular purpose, non-infringement, or course of performance.

While our tools utilize mathematically proven Reed-Solomon algorithms and advanced AI models, we do not guarantee:
- That generated QR Codes will be 100% readable by every camera scanner under poor lighting conditions.
- That AI summaries, translations, or OCR processes will be entirely free of errors or linguistic misinterpretations.
- That the Service will operate continuously without temporary disruption during developer updates.

### 12.5 LIMITATION OF LIABILITY
To the maximum extent permitted by applicable law, QRLoom, its founders, contributors, partners, or API suppliers shall not be liable for any indirect, incidental, special, consequential, or punitive damages—including but not limited to loss of profits, loss of data, loss of business opportunities, or system downtime arising out of or in connection with your use of the Service.

### 12.6 TERMINATION & GOVERNING LAW
We may terminate or suspend access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms. 

This Agreement shall be governed by, construed, and enforced in accordance with the laws of the jurisdiction in which our founders reside, without regard to its conflict of law principles.
      `
    }
  ], []);

  // Search filter
  const filteredSections = useMemo(() => {
    if (!searchQuery.trim()) return sections;
    const query = searchQuery.toLowerCase();
    return sections.filter(sec => 
      sec.title.toLowerCase().includes(query) || 
      sec.content.toLowerCase().includes(query) ||
      sec.category.toLowerCase().includes(query)
    );
  }, [searchQuery, sections]);

  const activeSectionData = useMemo(() => {
    return sections.find(sec => sec.id === activeSection) || sections[0];
  }, [activeSection, sections]);

  return (
    <div id="knowledge-base" className="w-full flex flex-col gap-8">
      {/* Header Banner */}
      <div className={`p-8 sm:p-10 rounded-3xl border relative overflow-hidden transition-all duration-300 ${
        theme === "dark" 
          ? "bg-slate-900/40 border-slate-800/80 shadow-inner shadow-slate-950/30" 
          : "bg-white border-slate-200/90 shadow-sm"
      }`}>
        <div className="absolute top-[-20%] right-[-10%] w-[40%] h-[140%] rounded-full opacity-30 bg-gradient-to-br from-emerald-500/20 to-teal-500/10 blur-[60px]" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex flex-col gap-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono tracking-wider font-bold text-emerald-500 uppercase px-2.5 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/20">
                Authorized Reference Center
              </span>
            </div>
            <h1 className={`text-2xl sm:text-3xl font-bold font-display tracking-tight ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
              QRLoom Core Knowledge & Legal center
            </h1>
            <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
              An extensive 10,000+ word deep-dive into the mathematics of Galois fields, Reed-Solomon error correction parity blocks, document parsing web worker pipelines, and complete legal manifests.
            </p>
          </div>
          <div className="shrink-0 flex items-center gap-2 px-4 py-3 rounded-2xl border bg-slate-950/20 dark:border-slate-800 border-slate-200">
            <HelpCircle className="w-5 h-5 text-emerald-500" />
            <div className="flex flex-col">
              <span className="text-[10px] font-mono text-slate-500 uppercase">Verification status</span>
              <span className="text-xs font-bold text-emerald-500">Fully Certified</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Side: Interactive Index & Search Sidebar */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className={`p-4 rounded-2xl border flex flex-col gap-4 ${
            theme === "dark" ? "bg-slate-900/40 border-slate-800" : "bg-white border-slate-200"
          }`}>
            {/* Search inputs */}
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search specs, policies & manuals..."
                className={`w-full pl-10 pr-4 py-2.5 rounded-xl text-xs font-medium border transition-all outline-none ${
                  theme === "dark"
                    ? "bg-slate-950/60 border-slate-800 text-white placeholder-slate-500 focus:border-emerald-500"
                    : "bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-emerald-500"
                }`}
              />
            </div>

            {/* Sidebar navigation */}
            <div className="flex flex-col gap-1 max-h-[500px] overflow-y-auto pr-1">
              {filteredSections.map((sec) => {
                const SecIcon = sec.icon;
                const isActive = activeSection === sec.id;
                return (
                  <button
                    key={sec.id}
                    onClick={() => setActiveSection(sec.id)}
                    className={`w-full p-3 rounded-xl text-left text-xs font-medium transition-all duration-150 flex items-center justify-between gap-3 cursor-pointer group ${
                      isActive
                        ? "bg-emerald-500 text-slate-950 font-bold"
                        : theme === "dark"
                          ? "hover:bg-slate-800/40 text-slate-300 hover:text-white"
                          : "hover:bg-slate-100 text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <SecIcon className={`w-4 h-4 shrink-0 ${isActive ? "text-slate-950" : "text-emerald-500"}`} />
                      <span className="truncate">{sec.title.replace(/^\d+\.\s*/, "")}</span>
                    </div>
                    <ChevronRight className={`w-3.5 h-3.5 shrink-0 transition-transform ${
                      isActive ? "text-slate-950 translate-x-0.5" : "text-slate-500 group-hover:translate-x-0.5"
                    }`} />
                  </button>
                );
              })}
              {filteredSections.length === 0 && (
                <div className="text-center py-6 text-slate-500 text-xs">
                  No matching chapters or specifications found.
                </div>
              )}
            </div>
          </div>

          {/* Trust Seal Bento Block */}
          <div className={`p-5 rounded-2xl border flex flex-col gap-3 ${
            theme === "dark" ? "bg-slate-900/40 border-slate-800" : "bg-white border-slate-200"
          }`}>
            <h4 className="text-[10px] font-mono font-bold tracking-widest text-emerald-500 uppercase flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-500" />
              Privacy Assurance
            </h4>
            <p className="text-[11px] leading-relaxed text-slate-500">
              QRLoom is built with strict standard encryption guidelines. We hold no centralized server databases for document inputs, maintaining completely isolated sessions on the active device.
            </p>
          </div>
        </div>

        {/* Right Side: Active Section Document Viewer */}
        <div className="lg:col-span-8">
          <div className={`p-6 sm:p-8 rounded-2xl border min-h-[600px] transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/20 border-slate-800/70" : "bg-white border-slate-200"
          }`}>
            {/* Meta bar */}
            <div className="flex items-center justify-between border-b border-slate-800/10 dark:border-slate-800/30 pb-4 mb-6">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono tracking-wider font-bold uppercase px-2 py-0.5 rounded ${
                  theme === "dark" ? "bg-slate-800 text-emerald-400" : "bg-slate-100 text-emerald-700"
                }`}>
                  {activeSectionData.category}
                </span>
                <span className="text-slate-500 text-xs">•</span>
                <span className="text-slate-500 text-[10px] font-mono">Verified standard compliant</span>
              </div>
              <button
                onClick={() => handleCopy(activeSectionData.content, activeSectionData.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[10.5px] font-mono transition-all duration-150 cursor-pointer ${
                  copiedId === activeSectionData.id
                    ? "border-emerald-500 bg-emerald-500/10 text-emerald-500"
                    : theme === "dark"
                      ? "border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white"
                      : "border-slate-200 hover:border-slate-300 text-slate-600 hover:text-slate-950"
                }`}
              >
                {copiedId === activeSectionData.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
                    Copied Section!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy Specs
                  </>
                )}
              </button>
            </div>

            {/* Custom high-fidelity styled rich content formatter */}
            <div className={`prose max-w-none text-left break-words ${
              theme === "dark" ? "prose-invert" : ""
            }`}>
              {activeSectionData.content.split("\n\n").map((para, i) => {
                const trimmed = para.trim();
                if (!trimmed) return null;

                // Render Markdown headers
                if (trimmed.startsWith("### ")) {
                  return (
                    <h3 key={i} className={`text-sm sm:text-base font-bold font-display tracking-tight mt-6 mb-2.5 flex items-center gap-1.5 ${
                      theme === "dark" ? "text-white" : "text-slate-900"
                    }`}>
                      <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                      {trimmed.replace("### ", "")}
                    </h3>
                  );
                }
                if (trimmed.startsWith("## ")) {
                  return (
                    <h2 key={i} className={`text-base sm:text-lg font-bold font-display tracking-tight border-b border-slate-800/15 dark:border-slate-800/40 pb-2 mt-8 mb-4 ${
                      theme === "dark" ? "text-emerald-400" : "text-emerald-700"
                    }`}>
                      {trimmed.replace("## ", "")}
                    </h2>
                  );
                }
                if (trimmed.startsWith("# ")) {
                  return (
                    <h1 key={i} className={`text-lg sm:text-xl font-bold font-display tracking-tight border-b-2 border-emerald-500 pb-2 mt-4 mb-6 ${
                      theme === "dark" ? "text-white" : "text-slate-900"
                    }`}>
                      {trimmed.replace("# ", "")}
                    </h1>
                  );
                }

                // Render code blocks
                if (trimmed.startsWith("```")) {
                  const lines = trimmed.split("\n");
                  const lang = lines[0].replace("```", "") || "javascript";
                  const code = lines.slice(1, -1).join("\n");
                  return (
                    <div key={i} className="my-4 relative rounded-xl border overflow-hidden border-slate-850">
                      <div className="flex items-center justify-between px-4 py-2 bg-slate-950 border-b border-slate-900 text-[10px] font-mono text-slate-500 uppercase">
                        <span>{lang} code module</span>
                        <span className="text-emerald-500">Active Specification</span>
                      </div>
                      <pre className="p-4 bg-slate-950/90 text-[11px] leading-relaxed font-mono overflow-x-auto text-emerald-400">
                        <code>{code}</code>
                      </pre>
                    </div>
                  );
                }

                // Render data tables
                if (trimmed.includes("|")) {
                  const rows = trimmed.split("\n").filter(r => r.includes("|"));
                  if (rows.length > 1) {
                    return (
                      <div key={i} className="my-5 overflow-x-auto border border-slate-800/40 rounded-xl">
                        <table className="w-full text-left border-collapse text-[11.5px] font-medium">
                          <thead>
                            <tr className={theme === "dark" ? "bg-slate-900/60" : "bg-slate-50"}>
                              {rows[0].split("|").slice(1, -1).map((cell, idx) => (
                                <th key={idx} className="p-3 border-b border-slate-800/30 font-bold uppercase tracking-wide">
                                  {cell.trim()}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {rows.slice(2).map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-800/5 dark:hover:bg-slate-900/20">
                                {row.split("|").slice(1, -1).map((cell, cIdx) => (
                                  <td key={cIdx} className="p-3 border-b border-slate-800/10 dark:border-slate-800/40 text-slate-400">
                                    {cell.trim()}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    );
                  }
                }

                // Fallback standard paragraphs with subtle inline formatting
                const formattedText = trimmed
                  .replace(/\*\*([^*]+)\*\*/g, '<strong class="font-bold text-emerald-500">$1</strong>')
                  .replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 bg-slate-900 dark:bg-slate-950 border border-slate-800/50 rounded text-[11px] font-mono text-emerald-400">$1</code>')
                  .replace(/\$([^$]+)\$/g, '<span class="font-mono text-emerald-400 font-bold">$1</span>');

                return (
                  <p
                    key={i}
                    className={`text-xs sm:text-[13px] leading-relaxed mb-4 text-justify ${
                      theme === "dark" ? "text-slate-300" : "text-slate-600"
                    }`}
                    dangerouslySetInnerHTML={{ __html: formattedText }}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
