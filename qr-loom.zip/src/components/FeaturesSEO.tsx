import { BookOpen, Shield, Cpu, Zap, Smartphone, Wifi, CreditCard, Share2 } from "lucide-react";

interface FeaturesSEOProps {
  theme?: "dark" | "light";
}

export default function FeaturesSEO({ theme = "dark" }: FeaturesSEOProps) {
  return (
    <div id="features-seo-section" className="relative w-full">
      {/* Background Blobs */}
      <div className="absolute top-1/4 left-1/3 w-80 h-80 rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full bg-teal-500/5 blur-[100px] pointer-events-none" />

      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="text-xs font-mono font-bold tracking-widest text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full uppercase">
          📚 Knowledge Hub & SEO Hub
        </span>
        <h2 className={`font-display font-bold text-4xl sm:text-5xl mt-4 tracking-tight leading-tight ${
          theme === "dark" ? "text-white" : "text-slate-900"
        }`}>
          Advanced QR Code Features <br />
          <span className="bg-gradient-to-r from-emerald-500 via-emerald-400 to-emerald-600 bg-clip-text text-transparent">
            & Technical Mechanics
          </span>
        </h2>
        <p className={`text-sm sm:text-base mt-4 max-w-xl mx-auto leading-relaxed ${
          theme === "dark" ? "text-slate-400" : "text-slate-600"
        }`}>
          Master the layout variables, error-correction standards, and professional branding options that govern vector-rendered matrix codes. 100% free with unlimited generation.
        </p>
      </div>

      {/* Section 1: Detailed Articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {/* Card 1 */}
        <div className={`border p-6 rounded-2xl flex flex-col gap-4 backdrop-blur-sm transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/40 border-slate-800/80"
            : "bg-white border-slate-200 shadow-sm"
        }`}>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className={`font-display font-bold text-lg leading-snug ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            What is a <span className="text-emerald-500 font-extrabold">free QR code generator</span>?
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            A Quick Response (QR) matrix barcode is a two-dimensional barcode readable by smartphones and optical lens trackers. A professional free QR code generator compiles input parameters (like URLs, credentials, or text streams) into standard binary matrix formats directly inside your browser using canvas layouts.
          </p>
        </div>

        {/* Card 2 */}
        <div className={`border p-6 rounded-2xl flex flex-col gap-4 backdrop-blur-sm transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/40 border-slate-800/80"
            : "bg-white border-slate-200 shadow-sm"
        }`}>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <Smartphone className="w-5 h-5" />
          </div>
          <h3 className={`font-display font-bold text-lg leading-snug ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            Professional Use Cases
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            Modern SaaS frameworks require contactless workflows. Key integrations include physical menu boards routing to PDF files, contactless vCard business credentials for corporate networking, digital receipt tracking, review collection links for local businesses, and responsive WiFi network logins.
          </p>
        </div>

        {/* Card 3 */}
        <div className={`border p-6 rounded-2xl flex flex-col gap-4 backdrop-blur-sm transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/40 border-slate-800/80"
            : "bg-white border-slate-200 shadow-sm"
        }`}>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className={`font-display font-bold text-lg leading-snug ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            Dynamic vs Static QR Coding
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            Static QR codes embed content directly within the matrix pattern—making them permanent and scannable offline forever. A <span className="text-emerald-500 font-bold">dynamic QR code</span> acts as a redirect proxy, sending the client to a shortened forwarding URL. This allows tracking metric analytics and modifying destinations without replacing physical prints.
          </p>
        </div>

        {/* Card 4 */}
        <div className={`border p-6 rounded-2xl flex flex-col gap-4 backdrop-blur-sm transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/40 border-slate-800/80"
            : "bg-white border-slate-200 shadow-sm"
        }`}>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <Wifi className="w-5 h-5" />
          </div>
          <h3 className={`font-display font-bold text-lg leading-snug ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            WiFi and vCard Networks
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            A customized <span className="text-emerald-500 font-bold">wifi qr code generator</span> formats security strings using specific syntaxes (WIFI:T:WPA;S:SSID;P:Pass;H:;) that let iOS and Android smartphones join local access points with a single scan. Similarly, vCard codes parse complete business listings into address books.
          </p>
        </div>

        {/* Card 5 */}
        <div className={`border p-6 rounded-2xl flex flex-col gap-4 backdrop-blur-sm transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/40 border-slate-800/80"
            : "bg-white border-slate-200 shadow-sm"
        }`}>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <CreditCard className="w-5 h-5" />
          </div>
          <h3 className={`font-display font-bold text-lg leading-snug ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            Crypto Ledger Ingress
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            By compiling specific coin headers like `bitcoin:` or `ethereum:` alongside hex transaction keys, users can scan and populate financial interfaces in seconds, eliminating clerical input errors on blockchain protocols.
          </p>
        </div>

        {/* Card 6 */}
        <div className={`border p-6 rounded-2xl flex flex-col gap-4 backdrop-blur-sm transition-all duration-300 ${
          theme === "dark"
            ? "bg-slate-900/40 border-slate-800/80"
            : "bg-white border-slate-200 shadow-sm"
        }`}>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <Share2 className="w-5 h-5" />
          </div>
          <h3 className={`font-display font-bold text-lg leading-snug ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            Social & Landing Integrations
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            Bundle complete marketing accounts (Instagram, LinkedIn, GitHub, YouTube) into unified redirect chains. By applying custom overlays like a <span className="text-emerald-500 font-bold">QR code with logo</span>, users instinctively recognize associated brands before triggering their smartphone camera lens.
          </p>
        </div>
      </div>

      {/* Section 2: Deep Technical Breakdown */}
      <div className={`rounded-3xl border p-8 mb-16 backdrop-blur-md transition-all duration-300 ${
        theme === "dark"
          ? "bg-slate-900/50 border-slate-800/80 text-slate-300"
          : "bg-white border-slate-200 text-slate-700 shadow-sm"
      }`}>
        <h3 className={`font-display font-bold text-2xl mb-6 flex items-center gap-2 ${
          theme === "dark" ? "text-white" : "text-slate-900"
        }`}>
          <Cpu className="w-6 h-6 text-emerald-500 animate-pulse" />
          Deep Dive: QR Code Error Correction & Alignment
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs sm:text-sm leading-relaxed">
          <div className="flex flex-col gap-4">
            <h4 className={`font-display font-bold text-base ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
              How Reed-Solomon Error Correction Works
            </h4>
            <p className={theme === "dark" ? "text-slate-300" : "text-slate-600"}>
              Every QR code generated on QRLoom incorporates Reed-Solomon mathematical error-correction formulas. This technology appends specific redundant data blocks (parity bits) onto the encoded binary stream. This allows scanning devices to read QR codes even if they are dirty, scratched, crumpled, or obscured by center logos.
            </p>
            <ul className={`list-disc pl-5 flex flex-col gap-1.5 text-xs ${
              theme === "dark" ? "text-slate-400" : "text-slate-500"
            }`}>
              <li><strong>Level L (Low)</strong>: Recovers up to 7% of missing data bytes. Offers smallest matrix density.</li>
              <li><strong>Level M (Medium)</strong>: Recovers up to 15% of missing data bytes. Standard for clean layouts.</li>
              <li><strong>Level Q (Quartile)</strong>: Recovers up to 25% of missing data bytes. Ideal for small center overlays.</li>
              <li><strong>Level H (High)</strong>: Recovers up to 30% of missing data bytes. Safest option for massive brand logo stamps.</li>
            </ul>
          </div>

          <div className={`flex flex-col gap-4 border-l pl-0 md:pl-8 ${
            theme === "dark" ? "border-slate-800" : "border-slate-100"
          }`}>
            <h4 className={`font-display font-bold text-base ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
              Logo Overlay & Readability Boundaries
            </h4>
            <p className={theme === "dark" ? "text-slate-300" : "text-slate-600"}>
              To stamp a custom logo in the center of a QR matrix, QRLoom calculates coordinate masks relative to the total pixel resolution of the canvas. Because a center image replaces part of the structural black-and-white grid modules, you MUST use Quartile (Q) or High (H) error correction.
            </p>
            <p className={theme === "dark" ? "text-slate-300" : "text-slate-600"}>
              Our renderer applies a translucent mask buffer around the custom logo boundary. This keeps the logo clear and readable without letting adjacent QR code modules touch or blend into it, ensuring rapid scanning on both iOS and Android cameras.
            </p>
          </div>
        </div>
      </div>

      {/* Section 3: Privacy & Security */}
      <div className={`rounded-3xl border p-8 flex flex-col md:flex-row items-center gap-8 shadow-xl transition-all duration-300 ${
        theme === "dark"
          ? "bg-gradient-to-r from-emerald-950/20 via-slate-900/50 to-emerald-950/20 border-slate-800/60"
          : "bg-gradient-to-r from-emerald-500/5 via-white to-emerald-500/5 border-slate-200"
      }`}>
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-500 shrink-0 shadow-lg">
          <Shield className="w-8 h-8" />
        </div>
        <div className="flex-1">
          <h3 className={`font-display font-bold text-xl mb-2 ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
            Our Absolute Privacy Commitment
          </h3>
          <p className={`text-xs sm:text-sm leading-relaxed ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
            Unlike commercial tracking hubs, QRLoom does not store your generated credentials or personal tracking links in any server database. All pixel coordinate calculations and color renderings occur entirely client-side using JavaScript canvas buffers inside your browser. No telemetry trackers, no adware, no logins, and 100% free of charge.
          </p>
        </div>
      </div>
    </div>
  );
}
