import React, { useState, useEffect, useRef } from "react";
import QRCode from "qrcode";
import jsQR from "jsqr";
import { motion, AnimatePresence } from "motion/react";
import {
  Link, FileText, Mail, MapPin, Phone, MessageSquare, Globe, Image as ImageIcon,
  Star, Wifi, Calendar, File, User, Send, Coins, Download, Copy, Trash2, History, Check, Upload, RefreshCw, Layers,
  ChevronRight, ArrowRight, ShieldAlert, CheckCircle, ExternalLink
} from "lucide-react";
import { QRType, ErrorCorrectionLevel, SavedQR } from "../types";

interface QRGeneratorProps {
  theme?: "dark" | "light";
}

export default function QRGenerator({ theme = "dark" }: QRGeneratorProps) {
  // Navigation for Categories
  const [activeTab, setActiveTab] = useState<QRType>(QRType.URL);

  // Field Values for the 15 types
  const [url, setUrl] = useState("https://www.mehtabnazar.xyz");
  const [text, setText] = useState("Hello from QRLoom Studio!");
  const [emailTo, setEmailTo] = useState("hello@mehtabnazar.xyz");
  const [emailSubject, setEmailSubject] = useState("Inquiry via QRLoom");
  const [emailBody, setEmailBody] = useState("Hi, I scanned your beautiful QR Code!");
  const [lat, setLat] = useState("37.7749");
  const [lng, setLng] = useState("-122.4194");
  const [phoneNum, setPhoneNum] = useState("+14155552671");
  const [whatsappNum, setWhatsappNum] = useState("+14155552671");
  const [whatsappMsg, setWhatsappMsg] = useState("Hello, I would like to inquire about QRLoom.");
  const [socialPlatform, setSocialPlatform] = useState("instagram");
  const [socialHandle, setSocialHandle] = useState("qrloom_official");
  const [imageUrl, setImageUrl] = useState("https://www.mehtabnazar.xyz/favicon.svg");
  const [reviewPlace, setReviewPlace] = useState("https://g.page/r/your-google-business-id/review");
  const [wifiSsid, setWifiSsid] = useState("QRLoom_Free_Wifi");
  const [wifiPassword, setWifiPassword] = useState("FreeAndUnlimited");
  const [wifiSecurity, setWifiSecurity] = useState("WPA");
  const [eventTitle, setEventTitle] = useState("QRLoom Launch Keynote");
  const [eventLocation, setEventLocation] = useState("San Francisco, CA");
  const [eventStart, setEventStart] = useState("2026-07-15T18:00");
  const [eventEnd, setEventEnd] = useState("2026-07-15T21:00");
  const [docUrl, setDocUrl] = useState("https://github.com/QR-LOOM/specification.pdf");
  const [vFirstName, setVFirstName] = useState("Syed");
  const [vLastName, setVLastName] = useState("Mehtab");
  const [vCompany, setVCompany] = useState("QRLoom Studio");
  const [vTitle, setVTitle] = useState("Founder & Lead Craftsman");
  const [vPhone, setVPhone] = useState("+14155552671");
  const [vEmail, setVEmail] = useState("hello@mehtabnazar.xyz");
  const [vUrl, setVUrl] = useState("https://www.mehtabnazar.xyz");
  const [smsNum, setSmsNum] = useState("+14155552671");
  const [smsMsg, setSmsMsg] = useState("Hey, send this SMS quickly!");
  const [cryptoCoin, setCryptoCoin] = useState("BTC");
  const [cryptoAddress, setCryptoAddress] = useState("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa");
  const [cryptoAmount, setCryptoAmount] = useState("");

  // Styling Settings
  const [foregroundColor, setForegroundColor] = useState("#10b981"); // Emerald green
  const [foregroundColor2, setForegroundColor2] = useState("#06b6d4"); // Cyan end
  const [fgType, setFgType] = useState<"solid" | "gradient">("gradient");
  const [gradientAngle, setGradientAngle] = useState(45);
  const [backgroundColor, setBackgroundColor] = useState("#ffffff"); // Background color for paper mode
  const [bgStyleMode, setBgStyleMode] = useState<"paper" | "seamless">("seamless");
  const [errorCorrectionLevel, setErrorCorrectionLevel] = useState<ErrorCorrectionLevel>("Q");

  // Mode & Scanner states
  const [mode, setMode] = useState<"generate" | "scan">("generate");
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [scannedImage, setScannedImage] = useState<string | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Scanner File Decoder Logic
  const handleScanFile = (file: File) => {
    if (!file) return;
    setScanError(null);
    setScanResult(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setScannedImage(dataUrl);

      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const tempCanvas = document.createElement("canvas");
        const tempCtx = tempCanvas.getContext("2d");
        if (!tempCtx) {
          setScanError("Failed to initialize canvas decoder context.");
          return;
        }

        tempCanvas.width = img.width;
        tempCanvas.height = img.height;
        tempCtx.drawImage(img, 0, 0);

        const imageData = tempCtx.getImageData(0, 0, img.width, img.height);
        try {
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code) {
            setScanResult(code.data);
            showToast("Successfully decoded QR code!");
          } else {
            setScanError("Could not find any readable QR code in this image. Make sure it's clear and centered.");
          }
        } catch (err) {
          console.error(err);
          setScanError("Decoder crashed during parsing. Please try another file.");
        }
      };
    };
    reader.onerror = () => {
      setScanError("Failed to read image file.");
    };
    reader.readAsDataURL(file);
  };

  const detectScannedType = (data: string): { type: QRType; cleanData: string } => {
    if (data.startsWith("http://") || data.startsWith("https://")) {
      return { type: QRType.URL, cleanData: data };
    }
    if (data.startsWith("mailto:")) {
      return { type: QRType.EMAIL, cleanData: data };
    }
    if (data.startsWith("tel:")) {
      return { type: QRType.PHONE, cleanData: data.replace("tel:", "") };
    }
    if (data.startsWith("geo:")) {
      return { type: QRType.LOCATION, cleanData: data };
    }
    if (data.startsWith("WIFI:")) {
      return { type: QRType.WIFI, cleanData: data };
    }
    if (data.startsWith("smsto:")) {
      return { type: QRType.SMS, cleanData: data };
    }
    return { type: QRType.TEXT, cleanData: data };
  };

  const handleImportScanned = () => {
    if (!scanResult) return;
    const { type, cleanData } = detectScannedType(scanResult);
    setActiveTab(type);

    if (type === QRType.URL) setUrl(cleanData);
    else if (type === QRType.TEXT) setText(cleanData);
    else if (type === QRType.PHONE) setPhoneNum(cleanData);
    else if (type === QRType.EMAIL) {
      const emailMatch = cleanData.match(/mailto:([^?]+)\?subject=([^&]+)&body=(.+)/);
      if (emailMatch) {
        setEmailTo(emailMatch[1]);
        setEmailSubject(decodeURIComponent(emailMatch[2]));
        setEmailBody(decodeURIComponent(emailMatch[3]));
      } else {
        setEmailTo(cleanData.replace("mailto:", ""));
      }
    } else {
      setText(cleanData);
    }

    setMode("generate");
    showToast(`Successfully imported into QR Generator Studio!`);
  };
  
  // Logo Settings
  const [logoOption, setLogoOption] = useState<"none" | "preset" | "upload">("none");
  const [presetLogo, setPresetLogo] = useState("globe");
  const [uploadedLogo, setUploadedLogo] = useState<string | null>(null);
  const [logoSize, setLogoSize] = useState(20); // % of total QR size

  // Text Caption Banner Options
  const [bannerEnabled, setBannerEnabled] = useState(false);
  const [bannerText, setBannerText] = useState("SCAN TO VISIT");
  const [bannerFontSize, setBannerFontSize] = useState(14);
  const [bannerBgColor, setBannerBgColor] = useState("#10b981");
  const [bannerTextColor, setBannerTextColor] = useState("#ffffff");

  // Interaction Toast Notifications
  const [toast, setToast] = useState<string | null>(null);
  const [isCopying, setIsCopying] = useState(false);
  const [isCopiedData, setIsCopiedData] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [qrName, setQrName] = useState("My QR Code");
  const [isPreviewScanning, setIsPreviewScanning] = useState(false);
  const [scanStatus, setScanStatus] = useState<"idle" | "scanning" | "success">("idle");

  const simulatePreviewScan = () => {
    setIsPreviewScanning(true);
    setScanStatus("scanning");
    setTimeout(() => {
      setScanStatus("success");
      setTimeout(() => {
        setIsPreviewScanning(false);
        setScanStatus("idle");
        showToast("Simulation: Code is perfectly readable!");
      }, 2000);
    }, 2500);
  };

  // History state
  const [history, setHistory] = useState<SavedQR[]>([]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const workerRef = useRef<Worker | null>(null);
  const requestIdRef = useRef<number>(0);

  // Initialize Web Worker for background QR rendering
  useEffect(() => {
    workerRef.current = new Worker(
      new URL("../workers/qr.worker.ts", import.meta.url),
      { type: "module" }
    );

    return () => {
      if (workerRef.current) {
        workerRef.current.terminate();
      }
    };
  }, []);

  // Quick Action Design Presets
  const templates = [
    { id: "modern-minimalist", name: "Modern Minimalist", fg: "#1f2937", fg2: "#111827", fgType: "solid" as const, bg: "#ffffff", mode: "paper" as const, logo: "none", logoOpt: "none" as const, desc: "Clean ink styling" },
    { id: "professional-corporate", name: "Professional Corporate", fg: "#1e3a8a", fg2: "#3b82f6", fgType: "gradient" as const, bg: "#ffffff", mode: "seamless" as const, logo: "globe", logoOpt: "preset" as const, desc: "Sleek blue enterprise gradient" },
    { id: "vibrant-social", name: "Vibrant Social", fg: "#db2777", fg2: "#f43f5e", fgType: "gradient" as const, bg: "#ffffff", mode: "seamless" as const, logo: "heart", logoOpt: "preset" as const, desc: "Warm rose social gradient" },
    { id: "cyberpunk-neon", name: "Cyberpunk Neon", fg: "#d946ef", fg2: "#06b6d4", fgType: "gradient" as const, bg: "#ffffff", mode: "seamless" as const, logo: "globe", logoOpt: "preset" as const, desc: "Vibrant neon mesh" },
    { id: "royal-gold", name: "Royal Gold", fg: "#b45309", fg2: "#f59e0b", fgType: "gradient" as const, bg: "#ffffff", mode: "seamless" as const, logo: "star", logoOpt: "preset" as const, desc: "Golden-amber premium layout" },
    { id: "forest-zen", name: "Forest Zen", fg: "#064e3b", fg2: "#10b981", fgType: "solid" as const, bg: "#f0fdf4", mode: "paper" as const, logo: "none", logoOpt: "none" as const, desc: "Organic dark green on mint" }
  ];

  // Dynamic Categories Definition (15 categories)
  const categories = [
    { type: QRType.URL, label: "URL Link", icon: Link },
    { type: QRType.TEXT, label: "Text", icon: FileText },
    { type: QRType.EMAIL, label: "Email", icon: Mail },
    { type: QRType.LOCATION, label: "Location", icon: MapPin },
    { type: QRType.PHONE, label: "Phone", icon: Phone },
    { type: QRType.WHATSAPP, label: "WhatsApp", icon: MessageSquare },
    { type: QRType.SOCIALS, label: "Socials", icon: Globe },
    { type: QRType.IMAGE, label: "Image Link", icon: ImageIcon },
    { type: QRType.REVIEW, label: "Review", icon: Star },
    { type: QRType.WIFI, label: "Wi-Fi", icon: Wifi },
    { type: QRType.EVENT, label: "Event", icon: Calendar },
    { type: QRType.PDF, label: "PDF / Doc", icon: File },
    { type: QRType.VCARD, label: "vCard", icon: User },
    { type: QRType.SMS, label: "SMS", icon: Send },
    { type: QRType.CRYPTO, label: "Crypto", icon: Coins },
  ];

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const handleApplyPreset = (tmpl: typeof templates[0]) => {
    setForegroundColor(tmpl.fg);
    setForegroundColor2(tmpl.fg2);
    setFgType(tmpl.fgType);
    setBackgroundColor(tmpl.bg);
    setBgStyleMode(tmpl.mode);
    setLogoOption(tmpl.logoOpt);
    if (tmpl.logoOpt === "preset") {
      setPresetLogo(tmpl.logo);
    }
    showToast(`Applied "${tmpl.name}" Design Style!`);
  };

  // Helper to construct actual data encoded into QR Code
  const getEncodedData = (): string => {
    switch (activeTab) {
      case QRType.URL:
        return url.startsWith("http://") || url.startsWith("https://") ? url : `https://${url}`;
      case QRType.TEXT:
        return text;
      case QRType.EMAIL:
        return `mailto:${emailTo}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      case QRType.LOCATION:
        return `geo:${lat},${lng}?q=${lat},${lng}`;
      case QRType.PHONE:
        return `tel:${phoneNum}`;
      case QRType.WHATSAPP:
        const waClean = whatsappNum.replace(/[+\s-]/g, "");
        return `https://wa.me/${waClean}?text=${encodeURIComponent(whatsappMsg)}`;
      case QRType.SOCIALS:
        if (socialPlatform === "instagram") return `https://instagram.com/${socialHandle}`;
        if (socialPlatform === "github") return `https://github.com/${socialHandle}`;
        if (socialPlatform === "linkedin") return `https://linkedin.com/in/${socialHandle}`;
        if (socialPlatform === "twitter") return `https://twitter.com/${socialHandle}`;
        return `https://example.com/${socialHandle}`;
      case QRType.IMAGE:
        return imageUrl;
      case QRType.REVIEW:
        return reviewPlace;
      case QRType.WIFI:
        return `WIFI:T:${wifiSecurity};S:${wifiSsid};P:${wifiPassword};H:false;`;
      case QRType.EVENT:
        const startStr = eventStart.replace(/[-:]/g, "") + "00Z";
        const endStr = eventEnd.replace(/[-:]/g, "") + "00Z";
        return `BEGIN:VEVENT\nSUMMARY:${eventTitle}\nLOCATION:${eventLocation}\nDTSTART:${startStr}\nDTEND:${endStr}\nEND:VEVENT`;
      case QRType.PDF:
        return docUrl;
      case QRType.VCARD:
        return `BEGIN:VCARD\nVERSION:3.0\nN:${vLastName};${vFirstName}\nFN:${vFirstName} ${vLastName}\nORG:${vCompany}\nTITLE:${vTitle}\nTEL;TYPE=CELL:${vPhone}\nEMAIL:${vEmail}\nURL:${vUrl}\nEND:VCARD`;
      case QRType.SMS:
        return `SMSTO:${smsNum}:${smsMsg}`;
      case QRType.CRYPTO:
        const scheme = cryptoCoin.toLowerCase();
        const amtParam = cryptoAmount ? `?amount=${cryptoAmount}` : "";
        return `${scheme}:${cryptoAddress}${amtParam}`;
      default:
        return "";
    }
  };

  const encodedData = getEncodedData();

  // Load Saved History
  useEffect(() => {
    try {
      const stored = localStorage.getItem("qrloom_history");
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Generates clean base64 data URLs for preset icons
  const getPresetLogoDataUrl = (type: string): string => {
    let svg = "";
    if (type === "globe") {
      svg = `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="${foregroundColor}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`;
    } else if (type === "whatsapp") {
      svg = `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="${foregroundColor}" stroke="none"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.002 5.291 5.3 0 11.794 0c3.148.001 6.107 1.227 8.329 3.453 2.222 2.226 3.444 5.187 3.444 8.337 0 6.51-5.298 11.799-11.792 11.799-2.001-.001-3.967-.512-5.712-1.488L0 24zm6.59-4.846c1.6.95 2.76 1.498 4.606 1.499 5.352 0 9.71-4.341 9.71-9.683 0-5.334-4.347-9.682-9.713-9.682-5.358 0-9.714 4.341-9.714 9.682 0 1.913.518 3.324 1.514 4.898L1.758 21.19l4.889-1.282z"/></svg>`;
    } else if (type === "wifi") {
      svg = `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="${foregroundColor}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13a10 10 0 0 1 14 0"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><path d="M2 9.5a15 15 0 0 1 20 0"/><circle cx="12" cy="20" r="1"/></svg>`;
    } else if (type === "heart") {
      svg = `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="${foregroundColor}" stroke="none"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`;
    } else {
      svg = `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="${foregroundColor}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
    }
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  };

  // Live Canvas Rendering function - supporting transparent background modes & bottom banner frame rendering!
  useEffect(() => {
    if (!canvasRef.current || !encodedData) return;

    setIsGenerating(true);
    const qrSize = 600; // Build at high-res internally (600x600)
    const requestId = ++requestIdRef.current;

    const drawBannerBlock = (ctx: CanvasRenderingContext2D, size: number, height: number) => {
      // Background banner block
      ctx.fillStyle = bannerBgColor;
      ctx.fillRect(0, size, size, height);

      // Center title text
      ctx.fillStyle = bannerTextColor;
      ctx.font = `bold ${bannerFontSize * 2}px "Inter", sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(bannerText.toUpperCase(), size / 2, size + (height / 2));
    };

    const renderWithModules = (size: number, data: Uint8Array) => {
      const canvas = canvasRef.current!;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        setIsGenerating(false);
        return;
      }

      const bannerHeight = bannerEnabled && bannerText.trim() ? 80 : 0;
      canvas.width = qrSize;
      canvas.height = qrSize + bannerHeight;

      // Clear target canvas
      ctx.clearRect(0, 0, qrSize, qrSize + bannerHeight);

      // Fill background if not seamless
      if (bgStyleMode !== "seamless") {
        ctx.fillStyle = backgroundColor;
        ctx.fillRect(0, 0, qrSize, qrSize + bannerHeight);
      }

      // 3. Create colored QR canvas using source-in compositing (Gradient / Solid)
      const qrColorCanvas = document.createElement("canvas");
      qrColorCanvas.width = qrSize;
      qrColorCanvas.height = qrSize;
      const qrColorCtx = qrColorCanvas.getContext("2d");
      if (qrColorCtx) {
        // Draw the black modules on the qrColorCanvas
        qrColorCtx.fillStyle = "#000000";
        const margin = 2;
        const totalModules = size + 2 * margin;
        const scale = qrSize / totalModules;
        for (let r = 0; r < size; r++) {
          for (let c = 0; c < size; c++) {
            if (data[r * size + c]) {
              const x = (c + margin) * scale;
              const y = (r + margin) * scale;
              qrColorCtx.fillRect(x, y, scale + 0.5, scale + 0.5);
            }
          }
        }

        qrColorCtx.globalCompositeOperation = "source-in";

        if (fgType === "gradient") {
          const angleRad = (gradientAngle * Math.PI) / 180;
          const r = qrSize / 2;
          const cx = qrSize / 2;
          const cy = qrSize / 2;
          const x0 = cx - Math.cos(angleRad) * r;
          const y0 = cy - Math.sin(angleRad) * r;
          const x1 = cx + Math.cos(angleRad) * r;
          const y1 = cy + Math.sin(angleRad) * r;

          const grad = qrColorCtx.createLinearGradient(x0, y0, x1, y1);
          grad.addColorStop(0, foregroundColor);
          grad.addColorStop(1, foregroundColor2);
          qrColorCtx.fillStyle = grad;
        } else {
          qrColorCtx.fillStyle = foregroundColor;
        }
        qrColorCtx.fillRect(0, 0, qrSize, qrSize);
      }

      // Draw generated colored QR code onto main canvas
      ctx.drawImage(qrColorCanvas, 0, 0);

      // 4. Draw Center Logo if active
      let finalLogoUrl: string | null = null;
      if (logoOption === "preset") {
        finalLogoUrl = getPresetLogoDataUrl(presetLogo);
      } else if (logoOption === "upload" && uploadedLogo) {
        finalLogoUrl = uploadedLogo;
      }

      if (finalLogoUrl) {
        const logoImage = new Image();
        logoImage.src = finalLogoUrl;
        logoImage.onload = () => {
          const logoDimension = qrSize * (logoSize / 100);
          const logoX = (qrSize - logoDimension) / 2;
          const logoY = (qrSize - logoDimension) / 2;

          // Draw rounded mask buffer
          ctx.fillStyle = bgStyleMode === "seamless" ? (theme === "dark" ? "#0f172a" : "#ffffff") : backgroundColor;
          ctx.beginPath();
          const radius = logoDimension * 0.15;
          ctx.roundRect(logoX - 6, logoY - 6, logoDimension + 12, logoDimension + 12, radius);
          ctx.fill();

          // Draw actual logo
          ctx.drawImage(logoImage, logoX, logoY, logoDimension, logoDimension);
          
          // Draw Banner if active (after logo loads to preserve layered ordering)
          if (bannerEnabled && bannerText.trim()) {
            drawBannerBlock(ctx, qrSize, bannerHeight);
          }
          setIsGenerating(false);
        };
        logoImage.onerror = () => {
          if (bannerEnabled && bannerText.trim()) {
            drawBannerBlock(ctx, qrSize, bannerHeight);
          }
          setIsGenerating(false);
        };
      } else {
        // If no logo, draw banner block directly
        if (bannerEnabled && bannerText.trim()) {
          drawBannerBlock(ctx, qrSize, bannerHeight);
        }
        setIsGenerating(false);
      }
    };

    const renderMainThreadFallback = async () => {
      try {
        const tempCanvas = document.createElement("canvas");
        await QRCode.toCanvas(tempCanvas, encodedData, {
          width: qrSize,
          margin: 2,
          errorCorrectionLevel: errorCorrectionLevel,
          color: {
            dark: "#000000",
            light: "#00000000",
          },
        });

        const canvas = canvasRef.current!;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          setIsGenerating(false);
          return;
        }

        const bannerHeight = bannerEnabled && bannerText.trim() ? 80 : 0;
        canvas.width = qrSize;
        canvas.height = qrSize + bannerHeight;

        ctx.clearRect(0, 0, qrSize, qrSize + bannerHeight);
        if (bgStyleMode !== "seamless") {
          ctx.fillStyle = backgroundColor;
          ctx.fillRect(0, 0, qrSize, qrSize + bannerHeight);
        }

        const qrColorCanvas = document.createElement("canvas");
        qrColorCanvas.width = qrSize;
        qrColorCanvas.height = qrSize;
        const qrColorCtx = qrColorCanvas.getContext("2d");
        if (qrColorCtx) {
          qrColorCtx.drawImage(tempCanvas, 0, 0);
          qrColorCtx.globalCompositeOperation = "source-in";

          if (fgType === "gradient") {
            const angleRad = (gradientAngle * Math.PI) / 180;
            const r = qrSize / 2;
            const cx = qrSize / 2;
            const cy = qrSize / 2;
            const x0 = cx - Math.cos(angleRad) * r;
            const y0 = cy - Math.sin(angleRad) * r;
            const x1 = cx + Math.cos(angleRad) * r;
            const y1 = cy + Math.sin(angleRad) * r;

            const grad = qrColorCtx.createLinearGradient(x0, y0, x1, y1);
            grad.addColorStop(0, foregroundColor);
            grad.addColorStop(1, foregroundColor2);
            qrColorCtx.fillStyle = grad;
          } else {
            qrColorCtx.fillStyle = foregroundColor;
          }
          qrColorCtx.fillRect(0, 0, qrSize, qrSize);
        }

        ctx.drawImage(qrColorCanvas, 0, 0);

        let finalLogoUrl: string | null = null;
        if (logoOption === "preset") {
          finalLogoUrl = getPresetLogoDataUrl(presetLogo);
        } else if (logoOption === "upload" && uploadedLogo) {
          finalLogoUrl = uploadedLogo;
        }

        if (finalLogoUrl) {
          const logoImage = new Image();
          logoImage.src = finalLogoUrl;
          logoImage.onload = () => {
            const logoDimension = qrSize * (logoSize / 100);
            const logoX = (qrSize - logoDimension) / 2;
            const logoY = (qrSize - logoDimension) / 2;

            ctx.fillStyle = bgStyleMode === "seamless" ? (theme === "dark" ? "#0f172a" : "#ffffff") : backgroundColor;
            ctx.beginPath();
            const radius = logoDimension * 0.15;
            ctx.roundRect(logoX - 6, logoY - 6, logoDimension + 12, logoDimension + 12, radius);
            ctx.fill();

            ctx.drawImage(logoImage, logoX, logoY, logoDimension, logoDimension);
            
            if (bannerEnabled && bannerText.trim()) {
              drawBannerBlock(ctx, qrSize, bannerHeight);
            }
            setIsGenerating(false);
          };
          logoImage.onerror = () => {
            if (bannerEnabled && bannerText.trim()) {
              drawBannerBlock(ctx, qrSize, bannerHeight);
            }
            setIsGenerating(false);
          };
        } else {
          if (bannerEnabled && bannerText.trim()) {
            drawBannerBlock(ctx, qrSize, bannerHeight);
          }
          setIsGenerating(false);
        }
      } catch (err) {
        setIsGenerating(false);
        console.error("Fallback QR Code rendering failed:", err);
      }
    };

    const worker = workerRef.current;
    if (worker) {
      worker.onmessage = (e: MessageEvent) => {
        if (requestId !== requestIdRef.current) return;
        const { success, size, data, error } = e.data;
        if (success) {
          renderWithModules(size, data);
        } else {
          console.error("Worker QR render failed, using fallback:", error);
          renderMainThreadFallback();
        }
      };

      worker.postMessage({
        text: encodedData,
        options: {
          errorCorrectionLevel,
        },
      });
    } else {
      renderMainThreadFallback();
    }
  }, [
    encodedData,
    foregroundColor,
    foregroundColor2,
    fgType,
    gradientAngle,
    backgroundColor,
    bgStyleMode,
    errorCorrectionLevel,
    logoOption,
    presetLogo,
    uploadedLogo,
    logoSize,
    bannerEnabled,
    bannerText,
    bannerFontSize,
    bannerBgColor,
    bannerTextColor,
    theme,
  ]);

  // Logo Upload handler
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedLogo(reader.result as string);
        setLogoOption("upload");
        showToast("Uploaded Custom Branding Logo!");
      };
      reader.readAsDataURL(file);
    }
  };

  // Download QR Code as High-Res PNG
  const handleDownload = () => {
    if (!canvasRef.current) return;
    const url = canvasRef.current.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `${qrName.toLowerCase().replace(/\s+/g, "-") || "qrloom"}-${activeTab}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast("Downloaded High-Resolution PNG!");
  };

  // Copy encoded string to clipboard
  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(encodedData);
      setIsCopiedData(true);
      setTimeout(() => setIsCopiedData(false), 2000);
      showToast("Copied raw data string!");
    } catch (e) {
      console.error(e);
    }
  };

  // Copy QR Code image directly to Clipboard (Replacing blocking alert with premium toast notification)
  const handleCopyImage = async () => {
    if (!canvasRef.current) return;
    setIsCopying(true);
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (blob) {
          await navigator.clipboard.write([
            new ClipboardItem({ "image/png": blob })
          ]);
          showToast("📋 Copy Success! QR Code Image copied to your clipboard.");
        }
        setIsCopying(false);
      }, "image/png");
    } catch (err) {
      console.error("Clipboard copy failed:", err);
      setIsCopying(false);
      showToast("Copy failed. Try downloading PNG directly instead.");
    }
  };

  // Save QR to History
  const handleSaveToHistory = () => {
    if (!encodedData) return;
    const newQR: SavedQR = {
      id: Math.random().toString(36).substring(2, 11),
      name: qrName || `${activeTab.toUpperCase()} Code`,
      type: activeTab,
      data: encodedData,
      settings: {
        foregroundColor,
        backgroundColor,
        errorCorrectionLevel,
        frameStyle: "rounded",
        logoUrl: logoOption === "upload" ? uploadedLogo || undefined : undefined,
        logoSize,
        margin: 2
      },
      createdAt: new Date().toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      })
    };

    const updated = [newQR, ...history].slice(0, 15);
    setHistory(updated);
    localStorage.setItem("qrloom_history", JSON.stringify(updated));
    showToast(`💾 Saved "${newQR.name}" to local history!`);
  };

  // Delete from History
  const handleDeleteHistory = (id: string) => {
    const updated = history.filter(item => item.id !== id);
    setHistory(updated);
    localStorage.setItem("qrloom_history", JSON.stringify(updated));
    showToast("Deleted configuration record.");
  };

  // Restore QR configuration from History
  const handleRestoreHistory = (saved: SavedQR) => {
    setActiveTab(saved.type);
    setQrName(saved.name);
    setForegroundColor(saved.settings.foregroundColor);
    setBackgroundColor(saved.settings.backgroundColor);
    setErrorCorrectionLevel(saved.settings.errorCorrectionLevel);
    if (saved.settings.logoUrl) {
      setUploadedLogo(saved.settings.logoUrl);
      setLogoOption("upload");
    } else {
      setLogoOption("none");
    }
    setLogoSize(saved.settings.logoSize);

    // Reconstruct forms
    if (saved.type === QRType.URL) setUrl(saved.data);
    else if (saved.type === QRType.TEXT) setText(saved.data);
    else if (saved.type === QRType.PHONE) setPhoneNum(saved.data.replace("tel:", ""));
    else if (saved.type === QRType.EMAIL) {
      const match = saved.data.match(/mailto:([^?]+)\?subject=([^&]+)&body=(.+)/);
      if (match) {
        setEmailTo(match[1]);
        setEmailSubject(decodeURIComponent(match[2]));
        setEmailBody(decodeURIComponent(match[3]));
      }
    }
    showToast(`Restored: ${saved.name}`);
    window.scrollTo({ top: 120, behavior: "smooth" });
  };

  return (
    <div id="qr-generator-section" className="relative w-full">
      {/* Background Blobs */}
      <div className="absolute -top-12 -left-16 w-72 h-72 rounded-full bg-emerald-500/10 blur-[100px] pointer-events-none animate-pulse" />
      <div className="absolute top-1/2 -right-24 w-96 h-96 rounded-full bg-teal-500/5 blur-[120px] pointer-events-none" />

      {/* Floating Snappy Custom Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-500 text-slate-950 font-display font-bold text-xs px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-2 border border-emerald-400/30 backdrop-blur-md animate-bounce">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>{toast}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="text-center max-w-4xl mx-auto mb-10">
        <span className="text-xs font-mono font-bold tracking-widest text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-4 py-1.5 rounded-full uppercase inline-flex items-center gap-1.5 shadow-sm">
          🚀 Completely Free & Unlimited Generation
        </span>
        <h1 className={`font-display font-bold text-4xl sm:text-5xl lg:text-6xl mt-5 tracking-tight leading-none ${
          theme === "dark" ? "text-white" : "text-slate-900"
        }`}>
          Craft Custom QR Codes <br />
          <span className="bg-gradient-to-r from-emerald-500 via-emerald-400 to-emerald-600 bg-clip-text text-transparent">
            Instantly & Offline
          </span>
        </h1>
        <p className={`text-base sm:text-lg mt-4 max-w-2xl mx-auto ${
          theme === "dark" ? "text-slate-400" : "text-slate-600"
        }`}>
          No sign-ups, no subscription limitations, and zero tracking. Generate high-resolution, vector-rendered matrix codes with logo stamps and layout captions inside your browser.
        </p>
      </div>

      {/* Mode Selector */}
      <div className="flex items-center justify-center mb-10 relative z-20">
        <div className={`flex p-1 rounded-2xl border backdrop-blur-md ${
          theme === "dark" ? "bg-slate-900/60 border-slate-800" : "bg-white/80 border-slate-200 shadow-sm"
        }`}>
          <motion.button
            onClick={() => setMode("generate")}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className={`px-5 py-2.5 rounded-xl font-display font-bold text-xs transition-all flex items-center gap-2 cursor-pointer ${
              mode === "generate"
                ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/25"
                : "text-slate-400 hover:text-emerald-500"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            QR Generator Studio
          </motion.button>
          <motion.button
            onClick={() => setMode("scan")}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className={`px-5 py-2.5 rounded-xl font-display font-bold text-xs transition-all flex items-center gap-2 cursor-pointer ${
              mode === "scan"
                ? "bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/25"
                : "text-slate-400 hover:text-emerald-500"
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            Scanner & Decoder Hub
          </motion.button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {mode === "generate" ? (
          <motion.div
            key="generate"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
          >
        {/* Left Column: Form & Design parameters */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {/* Quick Design Presets */}
          <div className={`rounded-2xl border p-5 backdrop-blur-md transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/50 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h3 className={`font-display text-[11px] font-bold uppercase tracking-wider mb-4 px-1 flex items-center justify-between ${
              theme === "dark" ? "text-slate-300" : "text-slate-800"
            }`}>
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
                Custom Design Style Templates
              </span>
              <span className="text-[9px] font-mono font-normal tracking-normal text-slate-500 uppercase">One-Click Apply</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {templates.map((tmpl) => (
                <motion.button
                  key={tmpl.id}
                  onClick={() => handleApplyPreset(tmpl)}
                  whileHover={{ scale: 1.02, translateY: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-3.5 border text-left rounded-xl transition-all cursor-pointer flex flex-col gap-2 relative overflow-hidden group ${
                    theme === "dark"
                      ? "bg-slate-950/40 border-slate-800/85 hover:bg-slate-950 hover:border-emerald-500/50"
                      : "bg-slate-50 border-slate-200 hover:bg-white hover:border-emerald-500/50 hover:shadow-sm"
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className={`text-[11px] font-bold tracking-tight ${theme === "dark" ? "text-white" : "text-slate-900"}`}>{tmpl.name}</span>
                    <div className="flex gap-1.5 items-center shrink-0">
                      {tmpl.fgType === "gradient" ? (
                        <div className="flex -space-x-1.5">
                          <span className="w-3 h-3 rounded-full border border-white/20 shrink-0 shadow-sm" style={{ backgroundColor: tmpl.fg }} />
                          <span className="w-3 h-3 rounded-full border border-white/20 shrink-0 shadow-sm" style={{ backgroundColor: tmpl.fg2 }} />
                        </div>
                      ) : (
                        <span className="w-3 h-3 rounded-full border border-white/20 shrink-0 shadow-sm" style={{ backgroundColor: tmpl.fg }} />
                      )}
                    </div>
                  </div>
                  
                  <p className={`text-[10px] leading-snug line-clamp-2 ${theme === "dark" ? "text-slate-500 group-hover:text-slate-400" : "text-slate-500 group-hover:text-slate-600"}`}>
                    {tmpl.desc}
                  </p>

                  <div className="flex items-center justify-between border-t border-slate-800/5 dark:border-slate-800/30 pt-1.5 mt-0.5 text-[9px] font-mono text-slate-500">
                    <span className="capitalize">{tmpl.mode} Mode</span>
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity text-emerald-500 font-bold font-sans">Apply ➔</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Tab Options */}
          <div className={`rounded-2xl border p-3.5 backdrop-blur-md transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/50 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h2 className={`font-display text-xs font-bold uppercase tracking-wider mb-2.5 px-1 ${
              theme === "dark" ? "text-slate-300" : "text-slate-800"
            }`}>
              1. Choose Content Type
            </h2>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isActive = activeTab === cat.type;
                return (
                  <motion.button
                    key={cat.type}
                    onClick={() => {
                      setActiveTab(cat.type);
                    }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`flex flex-col items-center justify-center gap-1.5 p-2 rounded-xl border text-center transition-all duration-150 cursor-pointer ${
                      isActive
                        ? "bg-emerald-500 border-emerald-400 text-slate-950 font-semibold shadow-md shadow-emerald-500/25"
                        : theme === "dark"
                          ? "bg-slate-950/40 border-slate-800/60 text-slate-400 hover:text-white hover:border-slate-700 hover:bg-slate-800/30"
                          : "bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-950 hover:bg-slate-100"
                    }`}
                  >
                    <Icon className="w-4 h-4 stroke-[2]" />
                    <span className="text-[10px] tracking-wide font-medium">{cat.label}</span>
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Form Fields Card */}
          <div className={`rounded-2xl border p-6 backdrop-blur-md flex flex-col gap-5 transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/50 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <div className={`flex items-center justify-between border-b pb-3 ${
              theme === "dark" ? "border-slate-800/80" : "border-slate-100"
            }`}>
              <h3 className={`font-display font-bold text-sm flex items-center gap-2 ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Fill Information ({categories.find(c => c.type === activeTab)?.label})
              </h3>
              <input
                type="text"
                value={qrName}
                onChange={(e) => setQrName(e.target.value)}
                placeholder="Give it a name..."
                className={`border rounded-lg px-2.5 py-1 text-xs max-w-[150px] text-right focus:outline-none focus:border-emerald-500 transition-all ${
                  theme === "dark" ? "bg-slate-950/60 border-slate-800/60 text-white" : "bg-slate-50 border-slate-200 text-slate-850"
                }`}
              />
            </div>

            {/* Render appropriate form fields */}
            <div className="min-h-[140px] flex flex-col justify-center">
              {activeTab === QRType.URL && (
                <div className="flex flex-col gap-2">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Destination URL Link</label>
                  <input
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://example.com/destination"
                    className={`w-full border text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                  <p className="text-[10.5px] text-slate-400">Perfect for blogs, links, portfolios, or payment gateways.</p>
                </div>
              )}

              {activeTab === QRType.TEXT && (
                <div className="flex flex-col gap-2">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Plain Text or Note</label>
                  <textarea
                    rows={4}
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Type anything you want to embed in the QR..."
                    className={`w-full border text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all resize-none ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                  <p className="text-[10.5px] text-slate-400">Encodes raw plaintext directly. Scannable offline.</p>
                </div>
              )}

              {activeTab === QRType.EMAIL && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5 sm:col-span-2">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>To Email Address</label>
                    <input
                      type="email"
                      value={emailTo}
                      onChange={(e) => setEmailTo(e.target.value)}
                      placeholder="support@qrloom.io"
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-emerald-500 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Subject Line</label>
                    <input
                      type="text"
                      value={emailSubject}
                      onChange={(e) => setEmailSubject(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Pre-filled Body</label>
                    <input
                      type="text"
                      value={emailBody}
                      onChange={(e) => setEmailBody(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.LOCATION && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Latitude</label>
                    <input
                      type="text"
                      value={lat}
                      onChange={(e) => setLat(e.target.value)}
                      placeholder="e.g. 34.0522"
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Longitude</label>
                    <input
                      type="text"
                      value={lng}
                      onChange={(e) => setLng(e.target.value)}
                      placeholder="e.g. -118.2437"
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.PHONE && (
                <div className="flex flex-col gap-2">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Phone Number (with Country Code)</label>
                  <input
                    type="tel"
                    value={phoneNum}
                    onChange={(e) => setPhoneNum(e.target.value)}
                    placeholder="+1234567890"
                    className={`w-full border text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                  <p className="text-[10.5px] text-slate-400">Scanning automatically prompts the dialer application.</p>
                </div>
              )}

              {activeTab === QRType.WHATSAPP && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1.5 sm:col-span-1">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>WhatsApp Number</label>
                    <input
                      type="tel"
                      value={whatsappNum}
                      onChange={(e) => setWhatsappNum(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-emerald-500 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5 sm:col-span-2">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Predefined text</label>
                    <input
                      type="text"
                      value={whatsappMsg}
                      onChange={(e) => setWhatsappMsg(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-emerald-500 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.SOCIALS && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Social Platform</label>
                    <select
                      value={socialPlatform}
                      onChange={(e) => setSocialPlatform(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    >
                      <option value="instagram">Instagram</option>
                      <option value="github">GitHub</option>
                      <option value="linkedin">LinkedIn</option>
                      <option value="twitter">X (Twitter)</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Handle / Username</label>
                    <input
                      type="text"
                      value={socialHandle}
                      onChange={(e) => setSocialHandle(e.target.value)}
                      placeholder="e.g. qrloom_official"
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-emerald-500 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.IMAGE && (
                <div className="flex flex-col gap-2">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Image Asset Web Link</label>
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className={`w-full border text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                  <p className="text-[10.5px] text-slate-400">Allows scanning to display your host image instantly in a browser.</p>
                </div>
              )}

              {activeTab === QRType.REVIEW && (
                <div className="flex flex-col gap-2">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Google Business or Yelp Review Link</label>
                  <input
                    type="url"
                    value={reviewPlace}
                    onChange={(e) => setReviewPlace(e.target.value)}
                    className={`w-full border text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                  <p className="text-[10.5px] text-slate-400">Boost client reviews by putting this QR code on cards or counters.</p>
                </div>
              )}

              {activeTab === QRType.WIFI && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Network SSID Name</label>
                    <input
                      type="text"
                      value={wifiSsid}
                      onChange={(e) => setWifiSsid(e.target.value)}
                      placeholder="Home_Wifi"
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>WiFi Password</label>
                    <input
                      type="text"
                      value={wifiPassword}
                      onChange={(e) => setWifiPassword(e.target.value)}
                      placeholder="WPA_Key"
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Security Type</label>
                    <select
                      value={wifiSecurity}
                      onChange={(e) => setWifiSecurity(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 focus:outline-none ${
                        theme === "dark" ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    >
                      <option value="WPA">WPA / WPA2</option>
                      <option value="WEP">WEP</option>
                      <option value="nopass">None (Open)</option>
                    </select>
                  </div>
                </div>
              )}

              {activeTab === QRType.EVENT && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Event Name</label>
                    <input
                      type="text"
                      value={eventTitle}
                      onChange={(e) => setEventTitle(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Venue / Location</label>
                    <input
                      type="text"
                      value={eventLocation}
                      onChange={(e) => setEventLocation(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.PDF && (
                <div className="flex flex-col gap-2">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Hosted Document link (.pdf/.docx)</label>
                  <input
                    type="url"
                    value={docUrl}
                    onChange={(e) => setDocUrl(e.target.value)}
                    className={`w-full border text-sm rounded-xl px-4 py-3 focus:outline-none focus:border-emerald-500 ${
                      theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                    }`}
                  />
                </div>
              )}

              {activeTab === QRType.VCARD && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="flex flex-col gap-1">
                    <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>First Name</label>
                    <input
                      type="text"
                      value={vFirstName}
                      onChange={(e) => setVFirstName(e.target.value)}
                      className={`border rounded-lg px-3 py-1.5 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Last Name</label>
                    <input
                      type="text"
                      value={vLastName}
                      onChange={(e) => setVLastName(e.target.value)}
                      className={`border rounded-lg px-3 py-1.5 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Company</label>
                    <input
                      type="text"
                      value={vCompany}
                      onChange={(e) => setVCompany(e.target.value)}
                      className={`border rounded-lg px-3 py-1.5 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className={`font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Job Title</label>
                    <input
                      type="text"
                      value={vTitle}
                      onChange={(e) => setVTitle(e.target.value)}
                      className={`border rounded-lg px-3 py-1.5 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.SMS && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1.5 col-span-1">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Recipient Phone</label>
                    <input
                      type="tel"
                      value={smsNum}
                      onChange={(e) => setSmsNum(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5 col-span-2">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Pre-filled SMS text</label>
                    <input
                      type="text"
                      value={smsMsg}
                      onChange={(e) => setSmsMsg(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}

              {activeTab === QRType.CRYPTO && (
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Coin</label>
                    <select
                      value={cryptoCoin}
                      onChange={(e) => setCryptoCoin(e.target.value)}
                      className={`w-full border text-sm rounded-xl px-4 py-2.5 ${
                        theme === "dark" ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    >
                      <option value="BTC">Bitcoin (BTC)</option>
                      <option value="ETH">Ethereum (ETH)</option>
                      <option value="SOL">Solana (SOL)</option>
                      <option value="DOGE">Dogecoin (DOGE)</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1.5 col-span-2">
                    <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>Crypto Address</label>
                    <input
                      type="text"
                      value={cryptoAddress}
                      onChange={(e) => setCryptoAddress(e.target.value)}
                      className={`w-full border text-xs rounded-xl px-4 py-3 ${
                        theme === "dark" ? "bg-slate-950/60 border-slate-800 text-white" : "bg-slate-50 border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Design Branding Options */}
          <div className={`rounded-2xl border p-6 backdrop-blur-md flex flex-col gap-5 transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/50 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h3 className={`font-display font-bold text-sm border-b pb-3 uppercase tracking-wider ${
              theme === "dark" ? "text-slate-300 border-slate-800/80" : "text-slate-800 border-slate-100"
            }`}>
              2. Design & Branding Options
            </h3>

            {/* Background Render Mode Toggle */}
            <div className="flex flex-col gap-2">
              <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
                Background Render Preset
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setBgStyleMode("seamless")}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    bgStyleMode === "seamless"
                      ? "bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm"
                      : theme === "dark"
                        ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white"
                        : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-950"
                  }`}
                >
                  ✨ Transparent / Seamless
                </button>
                <button
                  type="button"
                  onClick={() => setBgStyleMode("paper")}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    bgStyleMode === "paper"
                      ? "bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm"
                      : theme === "dark"
                        ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white"
                        : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-950"
                  }`}
                >
                  📄 Solid Paper (For Printing)
                </button>
              </div>
              <p className="text-[10px] text-slate-500">
                Seamless mode creates alpha transparent PNGs perfect for graphic design. Paper mode compiles a solid color backing suited for prints.
              </p>
            </div>

            {/* Colors */}
            <div className="flex flex-col gap-4">
              <div className={`border p-4 rounded-xl flex flex-col gap-3 ${
                theme === "dark" ? "bg-slate-950/40 border-slate-800/60" : "bg-slate-50 border-slate-200"
              }`}>
                <div className="flex items-center justify-between">
                  <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
                    Foreground Styling Fill
                  </label>
                  <div className="flex bg-slate-900 border border-slate-800 rounded-lg p-0.5">
                    <button
                      type="button"
                      onClick={() => setFgType("solid")}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-all cursor-pointer ${
                        fgType === "solid" ? "bg-emerald-500 text-slate-950" : "text-slate-400"
                      }`}
                    >
                      Solid
                    </button>
                    <button
                      type="button"
                      onClick={() => setFgType("gradient")}
                      className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-all cursor-pointer ${
                        fgType === "gradient" ? "bg-emerald-500 text-slate-950" : "text-slate-400"
                      }`}
                    >
                      Gradient
                    </button>
                  </div>
                </div>

                {fgType === "solid" ? (
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={foregroundColor}
                      onChange={(e) => setForegroundColor(e.target.value)}
                      className="w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent shrink-0"
                    />
                    <input
                      type="text"
                      value={foregroundColor}
                      onChange={(e) => setForegroundColor(e.target.value)}
                      className={`w-full border text-xs font-mono rounded-lg px-2.5 py-1.5 uppercase ${
                        theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] text-slate-500">Color 1 (Start)</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={foregroundColor}
                            onChange={(e) => setForegroundColor(e.target.value)}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent shrink-0"
                          />
                          <input
                            type="text"
                            value={foregroundColor}
                            onChange={(e) => setForegroundColor(e.target.value)}
                            className={`w-full border text-[10px] font-mono rounded-lg px-2 py-1 uppercase ${
                              theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] text-slate-500">Color 2 (End)</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={foregroundColor2}
                            onChange={(e) => setForegroundColor2(e.target.value)}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent shrink-0"
                          />
                          <input
                            type="text"
                            value={foregroundColor2}
                            onChange={(e) => setForegroundColor2(e.target.value)}
                            className={`w-full border text-[10px] font-mono rounded-lg px-2 py-1 uppercase ${
                              theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                            }`}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1">
                      <div className="flex items-center justify-between text-[10px] font-bold text-slate-500">
                        <span>Gradient Angle</span>
                        <span>{gradientAngle}°</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="360"
                        value={gradientAngle}
                        onChange={(e) => setGradientAngle(parseInt(e.target.value))}
                        className="w-full accent-emerald-500 h-1 rounded-lg cursor-pointer"
                      />
                    </div>
                  </div>
                )}
              </div>

              {bgStyleMode === "paper" && (
                <div className={`border p-3.5 rounded-xl ${
                  theme === "dark" ? "bg-slate-950/40 border-slate-800/60" : "bg-slate-50 border-slate-200"
                }`}>
                  <label className={`text-xs font-semibold block mb-1.5 ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
                    Solid Background Color
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={backgroundColor}
                      onChange={(e) => setBackgroundColor(e.target.value)}
                      className="w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent shrink-0"
                    />
                    <input
                      type="text"
                      value={backgroundColor}
                      onChange={(e) => setBackgroundColor(e.target.value)}
                      className={`w-full border text-xs font-mono rounded-lg px-2.5 py-1.5 uppercase ${
                        theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Error correction levels */}
            <div className="flex flex-col gap-2">
              <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
                Error Correction Cap (Reliability)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { level: "L", desc: "Low (7%)" },
                  { level: "M", desc: "Med (15%)" },
                  { level: "Q", desc: "Quart (25%)" },
                  { level: "H", desc: "High (30%)" },
                ].map((item) => (
                  <button
                    key={item.level}
                    type="button"
                    onClick={() => setErrorCorrectionLevel(item.level as ErrorCorrectionLevel)}
                    className={`py-2 px-1 rounded-xl text-[10.5px] font-bold border transition-all cursor-pointer text-center ${
                      errorCorrectionLevel === item.level
                        ? "bg-emerald-500/20 border-emerald-500 text-emerald-500"
                        : theme === "dark"
                          ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white"
                          : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    {item.desc}
                  </button>
                ))}
              </div>
            </div>

            {/* Logo Settings */}
            <div className={`flex flex-col gap-3 pt-4 border-t ${
              theme === "dark" ? "border-slate-800" : "border-slate-100"
            }`}>
              <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
                Center Logo Overlay
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setLogoOption("none")}
                  className={`py-2 px-3 text-xs rounded-xl border font-medium transition-all cursor-pointer ${
                    logoOption === "none"
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-500"
                      : theme === "dark"
                        ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white"
                        : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-950"
                  }`}
                >
                  No Logo
                </button>
                <button
                  type="button"
                  onClick={() => setLogoOption("preset")}
                  className={`py-2 px-3 text-xs rounded-xl border font-medium transition-all cursor-pointer ${
                    logoOption === "preset"
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-500"
                      : theme === "dark"
                        ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white"
                        : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-950"
                  }`}
                >
                  Preset Icon
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLogoOption("upload");
                    fileInputRef.current?.click();
                  }}
                  className={`py-2 px-3 text-xs rounded-xl border font-medium transition-all cursor-pointer ${
                    logoOption === "upload"
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-500"
                      : theme === "dark"
                        ? "bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white"
                        : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-950"
                  }`}
                >
                  Upload Custom
                </button>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleLogoUpload}
                accept="image/*"
                className="hidden"
              />

              {logoOption === "preset" && (
                <div className={`border p-3.5 rounded-xl flex flex-col gap-2.5 ${
                  theme === "dark" ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
                }`}>
                  <span className="text-slate-400 text-[10.5px]">Select preset brand icon</span>
                  <div className="flex items-center gap-3">
                    {["globe", "whatsapp", "wifi", "heart"].map((item) => (
                      <button
                        key={item}
                        type="button"
                        onClick={() => {
                          setPresetLogo(item);
                          showToast(`Selected preset logo: ${item}`);
                        }}
                        className={`w-9 h-9 flex items-center justify-center rounded-lg border uppercase text-xs font-mono font-bold transition-all cursor-pointer ${
                          presetLogo === item
                            ? "bg-emerald-500 text-slate-950 border-emerald-400"
                            : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
                        }`}
                      >
                        {item.charAt(0)}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {logoOption === "upload" && uploadedLogo && (
                <div className={`border p-3 rounded-xl flex items-center gap-4 ${
                  theme === "dark" ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
                }`}>
                  <div className="w-12 h-12 rounded bg-white border border-slate-200 overflow-hidden flex items-center justify-center p-1">
                    <img src={uploadedLogo} alt="Logo" className="max-w-full max-h-full object-contain" />
                  </div>
                  <div className="flex-1 flex flex-col">
                    <span className={`text-xs font-bold ${theme === "dark" ? "text-slate-200" : "text-slate-800"}`}>Custom branding active</span>
                    <button
                      type="button"
                      onClick={() => setUploadedLogo(null)}
                      className="text-red-500 hover:text-red-400 text-[10.5px] font-semibold text-left cursor-pointer"
                    >
                      Remove Logo
                    </button>
                  </div>
                </div>
              )}

              {logoOption !== "none" && (
                <div className={`border p-2.5 rounded-lg flex flex-col gap-1 ${
                  theme === "dark" ? "bg-slate-950/20 border-slate-800" : "bg-slate-100/50 border-slate-200"
                }`}>
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className={theme === "dark" ? "text-slate-400" : "text-slate-600"}>Logo Scale Size ({logoSize}%)</span>
                    <span className="text-emerald-500 font-mono font-bold">{logoSize}%</span>
                  </div>
                  <input
                    type="range"
                    min="15"
                    max="28"
                    value={logoSize}
                    onChange={(e) => setLogoSize(parseInt(e.target.value))}
                    className="w-full accent-emerald-500 h-1 rounded-lg cursor-pointer"
                  />
                </div>
              )}
            </div>

            {/* Premium Text Caption Banner Frame Options - Highly Requested Option! */}
            <div className={`flex flex-col gap-3 pt-4 border-t ${
              theme === "dark" ? "border-slate-800" : "border-slate-100"
            }`}>
              <div className="flex items-center justify-between">
                <label className={`text-xs font-semibold ${theme === "dark" ? "text-slate-400" : "text-slate-600"}`}>
                  Append Bottom Text Banner
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setBannerEnabled(!bannerEnabled);
                    showToast(bannerEnabled ? "Removed bottom text banner" : "Enabled bottom text banner!");
                  }}
                  className={`text-[10.5px] font-bold px-2 py-1 rounded transition-colors cursor-pointer ${
                    bannerEnabled
                      ? "bg-emerald-500/20 border border-emerald-500 text-emerald-500"
                      : "bg-slate-500/10 border border-transparent text-slate-400"
                  }`}
                >
                  {bannerEnabled ? "ACTIVE" : "DISABLED"}
                </button>
              </div>

              {bannerEnabled && (
                <div className={`border p-4 rounded-xl flex flex-col gap-3 text-xs ${
                  theme === "dark" ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
                }`}>
                  <div className="flex flex-col gap-1">
                    <span className={theme === "dark" ? "text-slate-400" : "text-slate-600"}>Banner Label Text</span>
                    <input
                      type="text"
                      maxLength={24}
                      value={bannerText}
                      onChange={(e) => setBannerText(e.target.value)}
                      placeholder="e.g. SCAN ME"
                      className={`border rounded-lg px-2.5 py-1.5 font-bold uppercase ${
                        theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                      }`}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3.5">
                    <div className="flex flex-col gap-1">
                      <span className={theme === "dark" ? "text-slate-400" : "text-slate-600"}>Banner Color</span>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="color"
                          value={bannerBgColor}
                          onChange={(e) => setBannerBgColor(e.target.value)}
                          className="w-7 h-7 rounded border-0 bg-transparent shrink-0 cursor-pointer"
                        />
                        <input
                          type="text"
                          value={bannerBgColor}
                          onChange={(e) => setBannerBgColor(e.target.value)}
                          className={`w-full text-[10px] font-mono rounded px-1.5 py-1 uppercase ${
                            theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                          }`}
                        />
                      </div>
                    </div>

                    <div className="flex flex-col gap-1">
                      <span className={theme === "dark" ? "text-slate-400" : "text-slate-600"}>Text Color</span>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="color"
                          value={bannerTextColor}
                          onChange={(e) => setBannerTextColor(e.target.value)}
                          className="w-7 h-7 rounded border-0 bg-transparent shrink-0 cursor-pointer"
                        />
                        <input
                          type="text"
                          value={bannerTextColor}
                          onChange={(e) => setBannerTextColor(e.target.value)}
                          className={`w-full text-[10px] font-mono rounded px-1.5 py-1 uppercase ${
                            theme === "dark" ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                          }`}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Premium Live QR Preview Box & History logs */}
        <div className="lg:col-span-5 flex flex-col gap-6 lg:sticky lg:top-28">
          {/* STICKY LIVE QR BOX */}
          <div className={`rounded-3xl border p-6 backdrop-blur-md shadow-2xl flex flex-col items-center transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/60 border-slate-800/80" : "bg-white border-slate-200 shadow-lg"
          }`}>
            <div className={`w-full flex items-center justify-between pb-3.5 mb-5 border-b ${
              theme === "dark" ? "border-slate-800/50" : "border-slate-100"
            }`}>
              <span className={`text-xs font-bold flex items-center gap-1.5 uppercase tracking-wide ${
                theme === "dark" ? "text-slate-300" : "text-slate-700"
              }`}>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                Live QR Preview
              </span>
              <span className="text-slate-400 text-[10px] font-mono font-semibold">100% Free & Unlimited</span>
            </div>

            {/* QR Canvas Display Frame with Premium Background & Scanner animation */}
            <div className={`relative group p-6 rounded-3xl border transition-all duration-300 max-w-full overflow-hidden ${
              bgStyleMode === "seamless"
                ? theme === "dark"
                  ? "bg-slate-950/80 border-slate-800 shadow-2xl shadow-emerald-950/5 hover:border-emerald-500/20"
                  : "bg-slate-50 border-slate-200 shadow-md hover:border-emerald-500/30"
                : "bg-white border-slate-200/60 shadow-xl"
            }`}>
              {/* Decorative Tech Rings - rotating slowly */}
              {bgStyleMode === "seamless" && (
                <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
                  <div className="w-72 h-72 rounded-full border border-dashed border-emerald-500/10 animate-[spin_40s_linear_infinite]" />
                  <div className="absolute w-60 h-60 rounded-full border border-double border-emerald-500/5 animate-[spin_20s_linear_infinite_reverse]" />
                </div>
              )}

              <div className="relative">
                <canvas
                  ref={canvasRef}
                  style={{ width: "240px", display: isGenerating ? "none" : "block" }}
                  className="mx-auto rounded-xl relative z-10 filter drop-shadow-md"
                />

                {/* Preview Scanning Simulation Overlay */}
                <AnimatePresence>
                  {isPreviewScanning && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-950/60 backdrop-blur-[2px] rounded-xl overflow-hidden border border-emerald-500/30"
                    >
                      {/* Viewfinder Target */}
                      <div className="w-[180px] h-[180px] border-2 border-emerald-500/40 relative">
                        {/* Corners */}
                        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                        <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
                        
                        {/* Scanning Bar Animation */}
                        {scanStatus === "scanning" && (
                          <motion.div
                            initial={{ top: 0 }}
                            animate={{ top: "100%" }}
                            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                            className="absolute left-0 right-0 h-1 bg-emerald-400 shadow-[0_0_8px_2px_rgba(52,211,153,0.5)]"
                          />
                        )}
                        
                        {/* Success Check */}
                        <AnimatePresence>
                          {scanStatus === "success" && (
                            <motion.div
                              initial={{ scale: 0, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              className="absolute inset-0 flex items-center justify-center bg-emerald-500/20 backdrop-blur-sm"
                            >
                              <div className="bg-emerald-500 rounded-full p-2">
                                <Check className="w-8 h-8 text-white stroke-[3]" />
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Status Text */}
                      <div className="mt-4 text-[10px] font-mono font-bold tracking-wider uppercase text-emerald-400">
                        {scanStatus === "scanning" ? "Analyzing Matrix..." : "Code Validated!"}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {isGenerating && (
                  <div className="w-[240px] h-[240px] mx-auto rounded-xl relative z-10 bg-slate-900/10 dark:bg-slate-950/40 flex flex-col items-center justify-center border border-slate-200 dark:border-slate-800 animate-pulse">
                    {/* Matrix scanning effect */}
                    <div className="grid grid-cols-6 gap-1 p-4 opacity-30">
                      {[...Array(36)].map((_, i) => (
                        <div key={i} className="w-2.5 h-2.5 bg-emerald-500 rounded-sm" style={{ animationDelay: `${(i % 6) * 150}ms` }} />
                      ))}
                    </div>
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-gradient-to-t from-slate-900/60 to-transparent">
                      <RefreshCw className="w-6 h-6 animate-spin text-emerald-500" />
                      <span className="text-[10px] font-mono font-bold tracking-wider text-slate-300 uppercase">Compiling QR module...</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Scan Laser graphic overlay */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-emerald-500/20 rounded-3xl pointer-events-none transition-all duration-300 z-20">
                {/* Laser scanline */}
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-emerald-500 to-transparent w-full opacity-0 group-hover:opacity-100 group-hover:animate-[bounce_2.5s_infinite] pointer-events-none" />
                
                {/* Visual Corner markers */}
                <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-emerald-500/80 opacity-0 group-hover:opacity-100 transition-all duration-300" />
                <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-emerald-500/80 opacity-0 group-hover:opacity-100 transition-all duration-300" />
                <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-emerald-500/80 opacity-0 group-hover:opacity-100 transition-all duration-300" />
                <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-emerald-500/80 opacity-0 group-hover:opacity-100 transition-all duration-300" />
              </div>
            </div>

            {/* Raw Encoded value container */}
            <div className={`w-full mt-6 border rounded-xl p-3 flex flex-col gap-1.5 ${
              theme === "dark" ? "bg-slate-950/80 border-slate-850" : "bg-slate-50 border-slate-200"
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-[9.5px] font-bold uppercase tracking-wider">
                  Raw Encoded Value
                </span>
                <button
                  type="button"
                  onClick={handleCopyText}
                  className="text-slate-400 hover:text-emerald-500 transition-colors cursor-pointer"
                  title="Copy encoded value"
                >
                  {isCopiedData ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <div className="text-[11px] font-mono text-emerald-500 leading-tight break-all max-h-16 overflow-y-auto pr-1">
                {encodedData}
              </div>
            </div>

            {/* Core Action Buttons */}
            <div className="w-full flex flex-col gap-3 mt-6">
              <motion.button
                type="button"
                onClick={simulatePreviewScan}
                disabled={isPreviewScanning}
                whileHover={{ scale: 1.025 }}
                whileTap={{ scale: 0.975 }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
                className={`w-full py-3 px-4 font-bold text-sm rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer border ${
                  theme === "dark" 
                    ? "bg-slate-900 hover:bg-slate-800 text-emerald-400 border-emerald-500/30"
                    : "bg-slate-50 hover:bg-slate-100 text-emerald-600 border-emerald-500/30 shadow-sm"
                }`}
              >
                <RefreshCw className={`w-4 h-4 ${isPreviewScanning ? 'animate-spin' : ''}`} />
                {isPreviewScanning ? "Analyzing Matrix..." : "Simulate Preview Scan"}
              </motion.button>

              <motion.button
                type="button"
                onClick={handleDownload}
                whileHover={{ scale: 1.025 }}
                whileTap={{ scale: 0.975 }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
                className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm rounded-xl shadow-lg shadow-emerald-500/10 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                Download High-Res PNG
              </motion.button>

              <div className="grid grid-cols-2 gap-3 w-full">
                <motion.button
                  type="button"
                  onClick={handleCopyImage}
                  disabled={isCopying}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  transition={{ type: "spring", stiffness: 400, damping: 15 }}
                  className={`py-2.5 px-3 border font-medium text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    theme === "dark"
                      ? "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700/50 hover:text-white"
                      : "bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:text-slate-950 shadow-sm"
                  }`}
                >
                  {isCopying ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Copy className="w-3.5 h-3.5" />}
                  Copy QR Image
                </motion.button>

                <motion.button
                  type="button"
                  onClick={handleSaveToHistory}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  transition={{ type: "spring", stiffness: 400, damping: 15 }}
                  className={`py-2.5 px-3 border font-medium text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    theme === "dark"
                      ? "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 hover:text-white"
                      : "bg-white hover:bg-slate-50 text-slate-700 border-slate-200 hover:text-slate-950 shadow-sm"
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  Save configurations
                </motion.button>
              </div>

              <span className="text-[10px] text-slate-400 text-center mt-1 block font-mono">
                ✓ 100% Free & Unlimited • High-Resolution Output • No Watermarks
              </span>
            </div>
          </div>

          {/* QR Configuration History Logs */}
          <div className={`rounded-2xl border p-5 backdrop-blur-md transition-all duration-300 ${
            theme === "dark" ? "bg-slate-900/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
          }`}>
            <h3 className={`font-display text-xs font-bold uppercase tracking-wider mb-3.5 flex items-center gap-1.5 ${
              theme === "dark" ? "text-slate-300" : "text-slate-800"
            }`}>
              <History className="w-3.5 h-3.5 text-emerald-500" />
              Recent QR Configurations ({history.length})
            </h3>

            {history.length === 0 ? (
              <div className={`text-center py-6 border border-dashed rounded-xl ${
                theme === "dark" ? "border-slate-800/60 bg-slate-950/20 text-slate-500" : "border-slate-200 bg-slate-50/50 text-slate-400"
              }`}>
                <p className="text-xs">No saved configurations in this session yet.</p>
                <p className="text-[10px] mt-1">Configure parameters and click "Save configurations" above.</p>
              </div>
            ) : (
              <div className="flex flex-col gap-2.5 max-h-60 overflow-y-auto pr-1">
                {history.map((item) => (
                  <div
                    key={item.id}
                    className={`flex items-center justify-between p-3 rounded-xl border text-xs transition-all ${
                      theme === "dark"
                        ? "bg-slate-950/50 border-slate-900 hover:border-slate-800 hover:bg-slate-950/80"
                        : "bg-slate-50 border-slate-100 hover:border-slate-200 hover:bg-white shadow-sm"
                    }`}
                  >
                    <div className="flex-1 min-w-0 pr-3">
                      <div className="flex items-center gap-2">
                        <span className={`font-semibold truncate ${theme === "dark" ? "text-slate-300" : "text-slate-800"}`}>{item.name}</span>
                        <span className="text-[9.5px] text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-1.5 rounded uppercase font-mono font-bold">
                          {item.type}
                        </span>
                      </div>
                      <p className="text-[10.5px] text-slate-400 truncate font-mono mt-0.5">{item.data}</p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleRestoreHistory(item)}
                        className={`py-1 px-2.5 font-semibold rounded-lg border transition-all text-[11px] cursor-pointer ${
                          theme === "dark"
                            ? "bg-slate-900 hover:bg-emerald-500 hover:text-slate-950 text-slate-400 border-slate-800 hover:border-emerald-400"
                            : "bg-white hover:bg-emerald-500 hover:text-slate-950 text-slate-600 border-slate-200 hover:border-emerald-400"
                        }`}
                      >
                        Restore
                      </button>
                      <button
                        onClick={() => handleDeleteHistory(item.id)}
                        className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                          theme === "dark"
                            ? "bg-slate-950 hover:bg-red-950 hover:text-red-400 text-slate-500 border-slate-900 hover:border-red-500/20"
                            : "bg-white hover:bg-red-50 hover:text-red-600 text-slate-400 border-slate-200 hover:border-red-200"
                        }`}
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </motion.div>
    ) : (
      <motion.div
        key="scan"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -15 }}
        transition={{ duration: 0.25 }}
        className="max-w-2xl mx-auto w-full pb-10"
      >
        <div className={`rounded-3xl border p-6 sm:p-8 backdrop-blur-md flex flex-col gap-6 transition-all duration-300 relative overflow-hidden ${
          theme === "dark" ? "bg-slate-900/50 border-slate-800/80" : "bg-white border-slate-200 shadow-xl"
        }`}>
          {/* Scan Decorative Corner Lines */}
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-emerald-500/60 rounded-tl-3xl pointer-events-none" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-emerald-500/60 rounded-tr-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-emerald-500/60 rounded-bl-3xl pointer-events-none" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-emerald-500/60 rounded-br-3xl pointer-events-none" />

          <div className="text-center max-w-lg mx-auto">
            <h3 className={`font-display font-bold text-xl ${theme === "dark" ? "text-white" : "text-slate-900"}`}>
              QR Decoder Engine
            </h3>
            <p className={`text-xs mt-1.5 ${theme === "dark" ? "text-slate-400" : "text-slate-500"}`}>
              Upload or drop any QR code image to decode it 100% locally on your device. Absolutely zero server-side transmissions.
            </p>
          </div>

          {/* Drag & Drop Upload Stage */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleScanFile(file);
            }}
            onClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "image/*";
              input.onchange = (e) => {
                const file = (e.target as HTMLInputElement).files?.[0];
                if (file) handleScanFile(file);
              };
              input.click();
            }}
            className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center gap-4 cursor-pointer relative overflow-hidden transition-all duration-300 min-h-[220px] ${
              isDragging
                ? "border-emerald-400 bg-emerald-500/5 shadow-inner"
                : theme === "dark"
                  ? "border-slate-800 bg-slate-950/25 hover:bg-slate-950/45 hover:border-slate-700"
                  : "border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-slate-400"
            }`}
          >
            {scannedImage ? (
              <div className="relative w-44 h-44 rounded-xl border border-slate-800 bg-slate-950 flex items-center justify-center p-2 group overflow-hidden">
                <img src={scannedImage} alt="Scanned QR" className="max-w-full max-h-full object-contain rounded-lg" />
                
                {/* Laser scanning sweep line effect */}
                <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-emerald-500 to-transparent top-0 animate-scanner-laser shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center border transition-all ${
                  theme === "dark" ? "bg-slate-900 border-slate-800 text-slate-400" : "bg-white border-slate-200 text-slate-600 shadow-sm"
                }`}>
                  <Upload className="w-5 h-5 animate-bounce" />
                </div>
                <div className="text-center">
                  <p className={`text-xs font-bold ${theme === "dark" ? "text-slate-200" : "text-slate-800"}`}>
                    Click to browse or drag & drop image
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">
                    Supports JPEG, PNG, WEBP, and SVG formats
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Scan Error Message */}
          {scanError && (
            <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/20 rounded-xl p-3.5 text-xs text-red-400">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <p className="font-semibold">{scanError}</p>
            </div>
          )}

          {/* Scan Result Dashboard */}
          {scanResult && (
            <div className={`flex flex-col gap-4 border p-5 rounded-2xl ${
              theme === "dark" ? "bg-slate-950/55 border-slate-800" : "bg-slate-50 border-slate-200"
            }`}>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4.5 h-4.5 text-emerald-500" />
                <span className={`text-xs font-bold ${theme === "dark" ? "text-slate-300" : "text-slate-800"}`}>
                  QR Code Successfully Parsed
                </span>
              </div>

              {/* Clean Result payload content box */}
              <div className="flex flex-col gap-1">
                <span className="text-[10px] text-slate-500 font-mono font-semibold uppercase tracking-wider">
                  Decoded Content Data:
                </span>
                <div className={`p-4 rounded-xl border font-mono text-xs break-all select-all ${
                  theme === "dark" ? "bg-slate-900/60 border-slate-800/80 text-emerald-400" : "bg-white border-slate-200 text-emerald-600 shadow-inner"
                }`}>
                  {scanResult}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(scanResult);
                    showToast("Copied decoded content!");
                  }}
                  className="py-2.5 px-4 font-semibold text-xs rounded-xl border flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-200"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Copy Content
                </button>

                {scanResult.match(/^https?:\/\//) && (
                  <a
                    href={scanResult}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-4 font-semibold text-xs rounded-xl border flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-emerald-500 hover:bg-emerald-400 border-emerald-400 text-slate-950 text-center"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Open URL
                  </a>
                )}

                <button
                  type="button"
                  onClick={handleImportScanned}
                  className="py-2.5 px-4 font-semibold text-xs rounded-xl border flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-slate-900 hover:bg-slate-800 border-slate-800 text-emerald-400 sm:col-span-1 col-span-full animate-pulse"
                >
                  <Layers className="w-3.5 h-3.5" />
                  Load in Studio
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    )}
  </AnimatePresence>
</div>
  );
}
