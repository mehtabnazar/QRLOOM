export enum QRType {
  URL = "url",
  TEXT = "text",
  EMAIL = "email",
  LOCATION = "location",
  PHONE = "phone",
  WHATSAPP = "whatsapp",
  SOCIALS = "socials",
  IMAGE = "image",
  REVIEW = "review",
  WIFI = "wifi",
  EVENT = "event",
  PDF = "pdf",
  VCARD = "vcard",
  SMS = "sms",
  CRYPTO = "crypto"
}

export type ErrorCorrectionLevel = "L" | "M" | "Q" | "H";
export type FrameStyle = "square" | "rounded" | "dots" | "classy";

export interface QRSettings {
  foregroundColor: string;
  backgroundColor: string;
  errorCorrectionLevel: ErrorCorrectionLevel;
  frameStyle: FrameStyle;
  logoUrl?: string;
  logoSize: number; // percentage of QR size
  margin: number;
}

export interface SavedQR {
  id: string;
  name: string;
  type: QRType;
  data: string;
  settings: QRSettings;
  createdAt: string;
}

export interface PDFTool {
  id: string;
  name: string;
  description: string;
  category: "convert-to-pdf" | "convert-from-pdf" | "edit-optimize" | "ai-powered";
  isAIPowered?: boolean;
}
