import QRCode from "qrcode";

self.onmessage = (e: MessageEvent) => {
  const { text, options } = e.data;
  try {
    const qr = QRCode.create(text, options);
    // qr.modules.data is a Uint8Array. We transfer its underlying buffer to the main thread
    const modulesData = new Uint8Array(qr.modules.data);
    self.postMessage(
      {
        success: true,
        size: qr.modules.size,
        data: modulesData,
      },
      [modulesData.buffer] as any
    );
  } catch (err: any) {
    self.postMessage({
      success: false,
      error: err?.message || String(err),
    });
  }
};
