import { useState, useEffect } from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import QRGenerator from "./components/QRGenerator";
import PDFTools from "./components/PDFTools";
import FeaturesSEO from "./components/FeaturesSEO";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import KnowledgeBase from "./components/KnowledgeBase";

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("home");
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("qrloom-theme");
      return (saved as "dark" | "light") || "dark";
    }
    return "dark";
  });

  // Automatically scroll to top on page switches
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [currentPage]);

  // Sync theme to local storage
  useEffect(() => {
    localStorage.setItem("qrloom-theme", theme);
  }, [theme]);

  // Inject JSON-LD structured schema for search engine optimization
  useEffect(() => {
    const schemaId = "saas-structured-schema";
    let scriptTag = document.getElementById(schemaId) as HTMLScriptElement;
    
    if (!scriptTag) {
      scriptTag = document.createElement("script");
      scriptTag.id = schemaId;
      scriptTag.type = "application/ld+json";
    }

    const schemaObj = {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": "QRLoom Studio & PDF AI Suite",
      "operatingSystem": "All",
      "applicationCategory": "BusinessApplication, MultimediaApplication",
      "offers": {
        "@type": "Offer",
        "price": "0.00",
        "priceCurrency": "USD"
      },
      "description": "Premium SaaS suite offering unlimited custom QR generation, high-fidelity designer branding configurations, and full AI document toolkits including summary, translation, OCR, and markdown.",
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "ratingCount": "1850"
      },
      "featureList": [
        "Gemini AI Document Summarizer",
        "Multimodal AI PDF Translation",
        "High-speed scan OCR extractor",
        "Custom designer QR Code builder with logos and caption banners",
        "Completely free with no watermarks and unlimited generations"
      ]
    };

    scriptTag.textContent = JSON.stringify(schemaObj);
    document.head.appendChild(scriptTag);

    return () => {
      const exist = document.getElementById(schemaId);
      if (exist) {
        exist.remove();
      }
    };
  }, []);

  return (
    <div className={`min-h-screen flex flex-col font-sans relative transition-colors duration-300 ${
      theme === "dark"
        ? "bg-slate-950 text-slate-100 selection:bg-emerald-500/30 selection:text-emerald-300"
        : "bg-slate-50 text-slate-900 selection:bg-emerald-500/20 selection:text-emerald-800"
    } overflow-x-hidden antialiased`}>
      
      {/* Immersive Motion Graphics Background - Theme-adaptive Floating Blobs & Grids */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Glowing Gradient Orb 1 */}
        <div className={`absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full opacity-60 animate-[pulse_8s_infinite] blur-[120px] transition-all duration-500 ${
          theme === "dark" ? "bg-emerald-500/10" : "bg-emerald-400/8"
        }`} />
        {/* Glowing Gradient Orb 2 */}
        <div className={`absolute bottom-[-15%] right-[-10%] w-[60%] h-[60%] rounded-full opacity-50 animate-[pulse_10s_infinite_1s] blur-[150px] transition-all duration-500 ${
          theme === "dark" ? "bg-teal-500/10" : "bg-teal-400/8"
        }`} />
        {/* Subtle grid pattern background overlay */}
        <div className={`absolute inset-0 bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] transition-all duration-500 ${
          theme === "dark"
            ? "bg-[linear-gradient(to_right,#0c1322_1px,transparent_1px),linear-gradient(to_bottom,#0c1322_1px,transparent_1px)] opacity-60"
            : "bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] opacity-50"
        }`} />
      </div>

      {/* Floating Sticky Glass Header */}
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} theme={theme} setTheme={setTheme} />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-24 z-10 relative">
        <div className="transition-all duration-300 ease-in-out">
          {currentPage === "home" && <QRGenerator theme={theme} />}
          {currentPage === "pdf" && <PDFTools theme={theme} />}
          {currentPage === "features" && <FeaturesSEO theme={theme} />}
          {currentPage === "faq" && <FAQ theme={theme} />}
          {currentPage === "contact" && <Contact theme={theme} />}
          {currentPage === "privacy" && <KnowledgeBase theme={theme} initialSection="privacy" />}
          {currentPage === "terms" && <KnowledgeBase theme={theme} initialSection="terms" />}
          {currentPage === "knowledge" && <KnowledgeBase theme={theme} initialSection="intro" />}
        </div>
      </main>

      {/* Footer with custom credit links */}
      <Footer setCurrentPage={setCurrentPage} theme={theme} />
    </div>
  );
}
